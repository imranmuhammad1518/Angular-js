import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response, Headers } from '@angular/http';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  
  getData = function(){
    
    var signUpPage = "userTableReference";	
    
   
     }

  routerLink="employee"


  constructor() { }

  ngOnInit() {
  }

}
