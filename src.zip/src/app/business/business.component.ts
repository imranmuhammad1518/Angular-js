import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {MatTableDataSource} from '@angular/material';


@Component({
  selector: 'app-business',
  templateUrl: './business.component.html',
  styleUrls: ['./business.component.css']
})
export class BusinessComponent implements OnInit {

  highlightedRows = [];
  //display column 
    displayedColumns = ['SelectAll','OSLogin', 'System', 'DataHub', 'SiteID', 'RSIEnabled', 'SODEnabled', 'TablesEnabled', 'LastUpdated', 'UpdatedBy'];
    dataSource = new MatTableDataSource<Element>(ELEMENT_DATA);

    //select All function
    checked = false;
    indeterminate = false;
    disabled = false;

    //dropdown functions
  shows = [
    {value: 'steak-0', viewValue: 'Next5'},
    {value: 'pizza-1', viewValue: 'Next5'},
    {value: 'tacos-2', viewValue: 'Next5'}
  ];

  constructor() { }

  ngOnInit() {
  }

  alertValue(){
    alert("hi coming");
  }

}

export interface Element {

  SelectAll: string;
  OSLogin: string;
  System: string;
  DataHub: string;
  SiteID: string;
  RSIEnabled: string;
  SODEnabled: string;
  TablesEnabled: string;
  LastUpdated: string;
  UpdatedBy: string;
}

const ELEMENT_DATA: Element[] = [
  {SelectAll: '', OSLogin: '[OS Login]', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]f', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {SelectAll: '', OSLogin: '[OS Login]', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]f', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {SelectAll: '', OSLogin: '[OS Login]', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]f', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {SelectAll: '', OSLogin: '[OS Login]', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]f', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {SelectAll: '', OSLogin: '[OS Login]', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]f', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
];