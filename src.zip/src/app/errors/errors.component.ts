import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material';

@Component({
  selector: 'app-errors',
  templateUrl: './errors.component.html',
  styleUrls: ['./errors.component.css']
})
export class ErrorsComponent implements OnInit {

//variables declaration
 hideErrorConfiguration:boolean = true;
 showAddErrorConfiguration:boolean;

//table header 
    tableColumnHeader = ['select', 'Error Code', 'Error Name', 'Error Description', 'Display Error', 'Updated DB', 'ReDisplay Error', 'Re UpdateDB', 'Last Updated', 'Updated By'];
    tableDataSource = new MatTableDataSource<Element>(ELEMENT_DATA);

//dropdown functions
  shows = [
    {viewValue: 'Next5'},
    {viewValue: 'Next10'},
    {viewValue: 'Next15'}
  ];

//radio button 
displayerrors = [
  'Always',
  'Never',
  'Depends'
  ];
updateDBValues= [
   'Always',
   'Never',
   'Depends'
   ];
reDisplayErrorValues= [
    'Always',
    'Never',
    'Depends'
    ];
 reUpdateDBValues= [
    'Always',
    'Never',
    'Depends'
    ];
    
    addError(){
      this.hideErrorConfiguration = false ;
      this.showAddErrorConfiguration = true;
    }
  
    cancelError(){
      this.hideErrorConfiguration = true ;
      this.showAddErrorConfiguration = false;
    }

  constructor() { }

  ngOnInit() {
  }

  alertValue(){
    alert("action working");
  }
}

export interface Element {

   ErrorCode: string;
   ErrorName: string;
   ErrorDescription: string;
   DisplayError: string;
   UpdatedDB: string;
   ReDisplayError: string;
   ReUpdateDB: string;
   LastUpdated: string;
   UpdatedBy: string;
}

const ELEMENT_DATA: Element[] = [
  {ErrorCode: '[Error Code]1', ErrorName: '[Error Name]', ErrorDescription: '[Error Description]', DisplayError: '[Never]', UpdatedDB: '[Depends]', ReDisplayError: '[Always]', ReUpdateDB: '[Never]', LastUpdated: '[12/05/2018]', UpdatedBy: 'Gupta Ranjith'},
  {ErrorCode: '[Error Code]2', ErrorName: '[Error Name]', ErrorDescription: '[Error Description]', DisplayError: '[Never]', UpdatedDB: '[Depends]', ReDisplayError: '[Always]', ReUpdateDB: '[Never]', LastUpdated: '[12/05/2018]', UpdatedBy: 'Gupta Ranjith'},
  {ErrorCode: '[Error Code]3', ErrorName: '[Error Name]', ErrorDescription: '[Error Description]', DisplayError: '[Never]', UpdatedDB: '[Depends]', ReDisplayError: '[Always]', ReUpdateDB: '[Never]', LastUpdated: '[12/05/2018]', UpdatedBy: 'Gupta Ranjith'},
  {ErrorCode: '[Error Code]4', ErrorName: '[Error Name]', ErrorDescription: '[Error Description]', DisplayError: '[Never]', UpdatedDB: '[Depends]', ReDisplayError: '[Always]', ReUpdateDB: '[Never]', LastUpdated: '[12/05/2018]', UpdatedBy: 'Gupta Ranjith'},
  {ErrorCode: '[Error Code]5', ErrorName: '[Error Name]', ErrorDescription: '[Error Description]', DisplayError: '[Never]', UpdatedDB: '[Depends]', ReDisplayError: '[Always]', ReUpdateDB: '[Never]', LastUpdated: '[12/05/2018]', UpdatedBy: 'Gupta Ranjith'},
  
];


