import { Component, OnInit, ViewChild, Injectable} from '@angular/core';
import {MatTableDataSource, MatSort, MatSortBase} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import {ChangeDetectorRef} from '@angular/core';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';

@Component({
  selector: 'app-custom-table',
  templateUrl: './custom-table.component.html',
  styleUrls: ['./custom-table.component.css'],
  inputs: ['tableColumnHeader','tableDataSource']
})
export class CustomTableComponent implements OnInit {
  
tableDataSource = this.tableDataSource;
selection = new SelectionModel<Element>(true, []);

// @ViewChild(MatSort) sort: MatSort;

// sortView() {
//   this.sort.direction = 'asc';
//   this.tableDataSource(this.sort);
// }

   /** Whether the number of selected elements matches the total number of rows. */
   isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.tableDataSource.data.length;
    return numSelected === numRows;
  }

  //delete selected row
   deleted(rowNumber: number)
{ 
  //alert(rowNumber);
  this.tableDataSource.splice(rowNumber, 1);
  //this.changeDetectorRef.detectChanges();
// delete(this.tableDataSource.data.forEach(row => this.selection.select(row)));
}

  
  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.tableDataSource.data.forEach(row => this.selection.select(row));
  }

  //dropdown functions
  shows = [
    {viewValue: 'Next5'},
    {viewValue: 'Next10'},
    {viewValue: 'Next15'}
  ];

  constructor() { }

  ngOnInit() {
    //this.data["hi"]= this.storage.get("hi");
  }

}