import { Component, OnInit, ViewChild, Injectable, ChangeDetectorRef } from '@angular/core';
import { MatTableDataSource, MatSort, MatCheckbox, MatPaginator } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { CDK_TABLE_TEMPLATE } from '@angular/cdk/table';
import { SortFilter } from '../sortFilter.pipe';
import { CustomTableModelBean } from './custom-table-model-bean';
import { Element } from '../system/system.component';

@Component({
  selector: 'app-custom-table',
  templateUrl: './custom-table.component.html',
  styleUrls: ['./custom-table.component.css'],
  inputs: ['uniqueValue', 'inputFilter1', 'inputFilter2', 'tableColumnHeader', 'tableDataSource']
})
export class CustomTableComponent implements OnInit {

  public customTableModelBean: CustomTableModelBean;

  //variables
  tableDataSource = this.tableDataSource;
  tableColumnHeader = this.tableColumnHeader;
  selection = new SelectionModel<Element>(true, []);
  uniqueValue = this.uniqueValue;
  noOfRowsPerPage = 5;
  inputFilterModel1;
  inputFilterModel2;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatCheckbox) myCheckbox: MatCheckbox;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngAfterViewInit() {
    this.tableDataSource.sort = this.sort;
    this.tableDataSource.paginator = this.paginator;
    this.tableDataSource.MatCheckbox = this.myCheckbox;
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.tableDataSource.data.length;
    return numSelected === numRows;
  }

  pageSort() {
     console.log(this.tableDataSource);
     //this.sort()

     //this.tableDataSource.data = this.sortingArray1(this.tableDataSource.data);
    //console.log(this.tableDataSource.data);
    // console.log(this.array_move(this.tableDataSource.data, 0, 1));
    //  this.tableDataSource.data = this.array_move(this.tableDataSource.data, 0, 1);
   
  }

  arraysortList(array: Array<any>): Array<string> {
    array.sort((a: any, b: any) => {
      if (a.name < b.name) {
        return -1;
      } else if (a.name > b.name) {
        return 1;
      } else {
        return 0;
      }
    });
    return array;
  }

  array_move(arr, old_index, new_index) {
    if (new_index >= arr.length) {
        var k = new_index - arr.length + 1;
        while (k--) {
            arr.push(undefined);
        }
    }
    arr.splice(new_index, 0, arr.splice(old_index, 1)[0]);
    return arr; 
}

  selectedOptionValue;
  pageView(selectedvalue, indexValue) {

    this.selectedOptionValue = selectedvalue;

    if (indexValue == 0) {
      this.paginator.pageSize = this.tableDataSource.data.length;
      this.paginator.pageIndex = 0;
    }
    else {
      this.paginator.pageSize = this.noOfRowsPerPage;
      this.paginator.pageIndex = indexValue - 1;
    }
    this.tableDataSource.paginator = this.paginator;
  }

  currentPageIndex;
  dropdownSelected;
  dropDownIndex;
  nextFiveRows() {
  
     this.currentPageIndex = this.paginator.pageIndex;
     this.dropDownIndex = this.currentPageIndex + 1;

     if(this.currentPageIndex != null){
    if (this.selectedOptionValue != null) {
      if (this.selectedOptionValue != this.shows[0].viewValue) {
        for (var u = 1; u < this.shows.length-1; u++) {
          if (this.selectedOptionValue == this.shows[u].viewValue && this.currentPageIndex != this.tableDataSource.data.length / this.noOfRowsPerPage - 1) {
            this.dropdownSelected = this.shows[parseInt(this.dropDownIndex) + 1].viewValue;
            break;
          }
        }
      }
    }
    else if (this.currentPageIndex < this.tableDataSource.data.length / this.noOfRowsPerPage - 1) {
      this.dropdownSelected = this.shows[parseInt(this.dropDownIndex) + 1].viewValue;
    }
    
    if ((this.paginator.pageSize == this.noOfRowsPerPage) && (this.paginator.pageSize != this.tableDataSource.data.length)) {
      if (this.currentPageIndex < this.tableDataSource.data.length / this.noOfRowsPerPage - 1) {
        this.paginator.pageIndex = this.currentPageIndex + 1;
        this.tableDataSource.paginator = this.paginator;
      }
    }
  }
}


  applyFilter(filterValue: string) {
    if (filterValue == '') {
      this.tableDataSource = new MatTableDataSource<Element>(this.tableDataSource.data);
      this.tableDataSource.paginator = this.paginator;
    }
  }

  //Filter data in table
  filterValue() {

    if (this.inputFilterModel1 != null) {

      this.inputFilterModel1 = this.inputFilterModel1.trim();
      for (var p = 0; p < this.tableDataSource.data.length; p++) {
        if (this.tableDataSource.data[p][this.uniqueValue] == this.inputFilterModel1) {
          this.tableDataSource.filter = this.inputFilterModel1;
        }
      }
    }

    if (this.inputFilterModel2 != null) {
      this.inputFilterModel2 = this.inputFilterModel2.trim();
      for (var a = 0; a < this.tableDataSource.data.length; a++) {
        if (this.tableDataSource.data[a][this.tableColumnHeader[2]] == this.inputFilterModel2) {
          this.tableDataSource.filter = this.inputFilterModel2;
        }
      }
    }
  }

  //deleting the selected rows in a table
  deleteSelectedRow() {

    this.selection.selected.forEach(item => {
      let index: number = this.tableDataSource.data.findIndex(d => d === item);
      this.tableDataSource.data.splice(index, 1)
      this.tableDataSource = new MatTableDataSource<Element>(this.tableDataSource.data);
    });
    this.tableDataSource.paginator = this.paginator;
    this.selection = new SelectionModel<Element>(true, []);
  }

  //sorthing an array 
  sortingArray(array) {
    array.sort((a: any, b: any) => {
      if (a < b) {
        return -1;
      } else if (a > b) {
        return 1;
      } else {
        return 0;
      }
    });
    return array;
  }
  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.tableDataSource.data.forEach(row => this.selection.select(row));
  }

  //dropdown functions
  shows = [
    { viewValue: 'Show All 25' },
    { viewValue: '1-5 of 25' },
    { viewValue: '6-10 of 25' },
    { viewValue: '11-15 of 25' },
    { viewValue: '16-20 of 25' },
    { viewValue: '21-25 of 25' }
  ];

  ngOnInit() {
    //to prevent back button in browser
    history.pushState(null, null, '');
    window.addEventListener('popstate', function (event) {
      history.pushState(null, null, '');
    });
    this.paginator.pageSize = this.noOfRowsPerPage;
    this.tableDataSource.paginator = this.paginator;
  }

  constructor() {
    this.customTableModelBean = new CustomTableModelBean();
  }

}