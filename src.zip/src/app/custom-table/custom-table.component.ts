import { Component, OnInit, ViewChild, Injectable} from '@angular/core';
import {MatTableDataSource, MatSort, MatSortBase} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import {ChangeDetectorRef} from '@angular/core';
import { Session } from 'selenium-webdriver';
import { UserComponent } from '../user/user.component';
import { CDK_TABLE_TEMPLATE } from '@angular/cdk/table';

@Component({
  selector: 'app-custom-table',
  templateUrl: './custom-table.component.html',
  styleUrls: ['./custom-table.component.css'],
  inputs: ['inputFilter1','inputFilter2','tableColumnHeader','tableDataSource']
})
export class CustomTableComponent implements OnInit {
  
tableDataSource = this.tableDataSource;
tableColumnHeader= this.tableColumnHeader;
selection = new SelectionModel<Element>(true, []);

// @ViewChild(MatSort) sort: MatSort;

// sortView() {
//   this.sort.direction = 'asc';
//   this.tableDataSource(this.sort);
// }

   /** Whether the number of selected elements matches the total number of rows. */
   isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.tableDataSource.data.length;
    return numSelected === numRows;
  }

  alertValue(){
    alert("hi"); 
  }

  inputFilterModel1
  inputFilterModel2;
  //Filter data in table
  filterValue() {
    var inputFilterModel1 = this.inputFilterModel1;
    var inputFilterModel2 = this.inputFilterModel2;

    if(inputFilterModel1 != null){
      inputFilterModel1 = inputFilterModel1.trim();
      inputFilterModel1 = inputFilterModel1.toLowerCase();
      this.tableDataSource.tableColumnHeader[1].filter = inputFilterModel1;
    }
    if(inputFilterModel2 != null){
      inputFilterModel2 = inputFilterModel2.trim();
    inputFilterModel2 = inputFilterModel2.toLowerCase();
    this.tableDataSource.tableColumnHeader[2].filter = inputFilterModel2;
    }
  }

    //delete selected row
  deleted(event,index)
  { 
    if(event.checked) {
    sessionStorage.setItem('session', index);
  }
  else{
    alert("unchecked");
    event.selection.clear();
  }
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.tableDataSource.data.forEach(row => this.selection.select(row));
  }

  //dropdown functions
  shows = [
    {viewValue: 'Next5'},
    {viewValue: 'Next10'},
    {viewValue: 'Next15'}
  ];


  ngOnInit() {}

  constructor(private changeDetectorRef: ChangeDetectorRef) {
  }

}