import { Component, OnInit, ViewChild, Injectable, ChangeDetectorRef} from '@angular/core';
import {MatTableDataSource, MatSort, MatSortBase, MatCheckbox, MatPaginator, MatRow} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import { UserComponent } from '../user/user.component';
import { CDK_TABLE_TEMPLATE } from '@angular/cdk/table';
import { SortFilter } from '../sortFilter.pipe';

@Component({
  selector: 'app-custom-table',
  templateUrl: './custom-table.component.html',
  styleUrls: ['./custom-table.component.css'],
  inputs: ['inputFilter1','inputFilter2','tableColumnHeader','tableDataSource']
})
export class CustomTableComponent implements OnInit {
  
tableDataSource = this.tableDataSource;
tableColumnHeader= this.tableColumnHeader;
selection = new SelectionModel<Element>(true, []);

@ViewChild(MatSort) sort: MatSort;
@ViewChild(MatRow) row: MatRow;
@ViewChild(MatCheckbox) myCheckbox: MatCheckbox;
@ViewChild(MatPaginator) paginator: MatPaginator;

ngAfterViewInit() {
  this.tableDataSource.sort = this.sort;
  this.tableDataSource.paginator = this.paginator;
  this.tableDataSource.MatCheckbox = this.myCheckbox;
}

   /** Whether the number of selected elements matches the total number of rows. */
   isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.tableDataSource.data.length;
    return numSelected === numRows;
  }

  alertValue(){
    alert("hi"); 
  }

  inputFilterModel1
  inputFilterModel2;
  //Filter data in table
  filterValue() {
    var inputFilterModel1 = this.inputFilterModel1;
    var inputFilterModel2 = this.inputFilterModel2;

    if(inputFilterModel1 != null){
      inputFilterModel1 = inputFilterModel1.trim();
      inputFilterModel1 = inputFilterModel1.toLowerCase();
      this.tableDataSource.filter = inputFilterModel1;
    }
    if(inputFilterModel2 != null){
      inputFilterModel2 = inputFilterModel2.trim();
    inputFilterModel2 = inputFilterModel2.toLowerCase();
    this.tableDataSource.filter = inputFilterModel2;
    }
  }

  
  indexValue= [];
  pageIndex;
  sample;
//delete selected row
  selectedRow(event,checkBoxIndex, osLoginId)
  { 
      this.pageIndex = this.paginator.pageIndex;
      
      //alert(osLoginId);
      if(event.checked) {
        if(this.pageIndex <= 5){
        //alert();
        //alert(index); .data[index].OSLogin
      console.log(this.tableDataSource.data.find(x => x.OSLogin == osLoginId));
      //this.indexValue.push(this.tableDataSource.data[index].OSLogin);
      this.indexValue.push(osLoginId);
        }
  }
  else{
    alert("unchecked");
    this.indexValue.slice(osLoginId);
    event.selection.clear();
  }
  this.indexValue.sort();
  }

  deleteSelectedRow(){
    //alert(this.tableDataSource.data.length);
     for(var i=0; i<this.tableDataSource.length;i++ ){
       alert(i);
       this.tableDataSource.data.splice(this.indexValue[i]-1,1);
       this.tableDataSource = new MatTableDataSource<Element>(this.tableDataSource.data);
    }
    this.tableDataSource.paginator = this.paginator;
     for(var i=0; i<=this.tableDataSource.length;i++ ){
      this.indexValue.splice(parseInt[i],1);
   }
     this.selection.clear();
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.tableDataSource.data.forEach(row => this.selection.select(row));
  }

  //dropdown functions
  shows = [
    {viewValue: 'Next5'},
    {viewValue: 'Next10'},
    {viewValue: 'Next15'}
  ];


  ngOnInit() {}

  constructor() {
  }

}