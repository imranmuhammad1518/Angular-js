import { Component, OnInit, ViewChild, Injectable, ChangeDetectorRef } from '@angular/core';
import { MatTableDataSource, MatSort, MatSortBase, MatCheckbox, MatPaginator, MatRow, MatColumnDef } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { CDK_TABLE_TEMPLATE } from '@angular/cdk/table';
import { SortFilter } from '../sortFilter.pipe';
import { CustomTableModelBean } from './custom-table-model-bean';

@Component({
  selector: 'app-custom-table',
  templateUrl: './custom-table.component.html',
  styleUrls: ['./custom-table.component.css'],
  inputs: ['uniqueValue', 'inputFilter1', 'inputFilter2', 'tableColumnHeader', 'tableDataSource']
})
export class CustomTableComponent implements OnInit {

  public customTableModelBean: CustomTableModelBean;

  tableDataSource = this.tableDataSource;
  tableColumnHeader = this.tableColumnHeader;
  selection = new SelectionModel<Element>(true, []);
  uniqueValue = this.uniqueValue;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatColumnDef) column: MatColumnDef;
  @ViewChild(MatCheckbox) myCheckbox: MatCheckbox;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngAfterViewInit() {
    this.tableDataSource.sort = this.sort;
    this.tableDataSource.paginator = this.paginator;
    this.tableDataSource.MatCheckbox = this.myCheckbox;
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.tableDataSource.data.length;
    return numSelected === numRows;
  }

  alertValue() {
    alert("hi");
  }

  inputFilterModel1
  inputFilterModel2;
  //Filter data in table
  filterValue() {
    var inputFilterModel1 = this.inputFilterModel1;
    var inputFilterModel2 = this.inputFilterModel2;
    //console.log(this.column.headerCell);
    if (inputFilterModel1 != null) {
      inputFilterModel1 = inputFilterModel1.trim();
      inputFilterModel1 = inputFilterModel1.toLowerCase();
      this.tableDataSource.filter = inputFilterModel1;
    }
    if (inputFilterModel2 != null) {
      inputFilterModel2 = inputFilterModel2.trim();
      inputFilterModel2 = inputFilterModel2.toLowerCase();
      this.tableDataSource.filter = inputFilterModel2;
    }
  }


  indexValue = [];
  pageIndex;
  OSLogin: string;
  primaryKeyValue: Number;
  uniqueValueCurrentFromTable:Number;
  finalIndexValue = [];
  //store selected row index to delete
  storeSelectedRow(event, checkBoxIndex, selectedRow) {

    //this.pageIndex = this.paginator.pageIndex;
    var selectedUniqueValue = this.uniqueValue;
    var selectedUniqueArray = Object.assign({}, selectedRow[selectedUniqueValue]);
    this.primaryKeyValue = selectedUniqueArray[0];
    if (selectedUniqueArray[1] != null) {
      this.primaryKeyValue = selectedUniqueArray[0] + selectedUniqueArray[1];
    }

    if (event.checked) {
      //this.new.push(this.tableDataSource.data.find(x => x.OSLogin == osLoginId));
      for (var i = 0; i < this.tableDataSource.data.length; i++) {
        var  indexFromCurrentTable= Object.assign({}, this.tableDataSource.data[i][selectedUniqueValue]);
        this.uniqueValueCurrentFromTable = indexFromCurrentTable[0];
        console.log(indexFromCurrentTable);
        if(indexFromCurrentTable[1]!= null){
          alert(indexFromCurrentTable[1]);
          this.uniqueValueCurrentFromTable = indexFromCurrentTable[0] + indexFromCurrentTable[1];
        }
        this.customTableModelBean.setOsLoginValue(this.uniqueValueCurrentFromTable);
        alert(this.customTableModelBean.getOsLoginValue());
        if (this.customTableModelBean.getOsLoginValue() == this.primaryKeyValue) {
          alert(i);
          this.indexValue.push(i);
          break;
        }
      }
    }
    else {
      for (var j = 0; j < this.indexValue.length; j++) {
        var unCheckIndexRemove = this.tableDataSource.data[this.indexValue[j]].OSLogin;
        if (unCheckIndexRemove == this.primaryKeyValue) {
          this.indexValue.splice(j, 1);
        }
      }
      this.selection[checkBoxIndex].clear();
    }
    this.finalIndexValue = this.sortingArray(this.indexValue);
  }

  //deleting the selected rows in a table
  deleteSelectedRow() {
    var a = 0;
    for (var i = 0; i < this.finalIndexValue.length; i++) {
      this.tableDataSource.data.splice(this.finalIndexValue[i] - a, 1);
      this.tableDataSource = new MatTableDataSource<Element>(this.tableDataSource.data);
      this.tableDataSource.paginator = this.paginator;
      a++;
    }
    for (var i = 0; i <= this.indexValue.length; i++) {
      this.indexValue.splice(parseInt[i], 1);
    }
    this.selection.clear();
  }

  //sorthing an array 
  sortingArray(array) {
    array.sort((a: any, b: any) => {
      if (a < b) {
        return -1;
      } else if (a > b) {
        return 1;
      } else {
        return 0;
      }
    });
    return array;
  }
  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.tableDataSource.data.forEach(row => this.selection.select(row));
  }

  //dropdown functions
  shows = [
    { viewValue: 'Next5' },
    { viewValue: 'Next10' },
    { viewValue: 'Next15' }
  ];

  ngOnInit() { }

  constructor() {
    this.customTableModelBean = new CustomTableModelBean();
  }

}