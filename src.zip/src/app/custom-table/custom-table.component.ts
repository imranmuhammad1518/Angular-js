import { Component, OnInit, ViewChild, Injectable, ChangeDetectorRef } from '@angular/core';
import { MatTableDataSource, MatSort, Sort, MatSortHeader, MatSortBase, MatCheckbox, MatPaginator, MatRow, MatColumnDef } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { CDK_TABLE_TEMPLATE } from '@angular/cdk/table';
import { SortFilter } from '../sortFilter.pipe';
import { CustomTableModelBean } from './custom-table-model-bean';
import { Element } from '../system/system.component';

@Component({
  selector: 'app-custom-table',
  templateUrl: './custom-table.component.html',
  styleUrls: ['./custom-table.component.css'],
  inputs: ['uniqueValue', 'inputFilter1', 'inputFilter2', 'tableColumnHeader', 'tableDataSource']
})
export class CustomTableComponent implements OnInit {

  public customTableModelBean: CustomTableModelBean;

  //variables
  tableDataSource = this.tableDataSource;
  tableColumnHeader = this.tableColumnHeader;
  selection = new SelectionModel<Element>(true, []);
  uniqueValue = this.uniqueValue;
  inputFilterModel1;
  inputFilterModel2;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatSortHeader) sortHeader: MatSortHeader;
  @ViewChild(MatColumnDef) column: MatColumnDef;
  @ViewChild(MatCheckbox) myCheckbox: MatCheckbox;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngAfterViewInit() {
    this.tableDataSource.sort = this.sort;
    this.tableDataSource.sortHeader = this.sortHeader;
    this.tableDataSource.paginator = this.paginator;
    this.tableDataSource.MatCheckbox = this.myCheckbox;
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.tableDataSource.data.length;
    return numSelected === numRows;
  }

  sortingArray1(array) {
    console.log(array);
    array.sort((a: any, b: any) => {
      if (a.column1 < b.column1) {
        return -1;
      } else if (a.column1 > b.column1) {
        return 1;
      } else {
        return 0;
      }
    });
    console.log(array);
    return array;
  }

  pageSort() {
     console.log(this.tableDataSource);
     this.tableDataSource.data = this.sortingArray1(this.tableDataSource.data);
    console.log(this.tableDataSource.data);
  }


  pageView(indexValue) {

    if (indexValue == 0) {
      this.paginator.pageSize = this.tableDataSource.data.length;
      this.paginator.pageIndex = 0;
    }
    else {
      this.paginator.pageSize = 5;
      this.paginator.pageIndex = indexValue - 1;
    }
    this.tableDataSource.paginator = this.paginator;
  }

  currentPageIndex;
  nextFiveRows() {
    this.currentPageIndex = this.paginator.pageIndex;
    if ((this.paginator.pageSize == 5) && (this.paginator.pageSize != this.tableDataSource.data.length)) {
      if (this.currentPageIndex < this.tableDataSource.data.length / 5 - 1) {
        this.paginator.pageIndex = this.currentPageIndex + 1;
        this.tableDataSource.paginator = this.paginator;
      }
    }
  }


  applyFilter(filterValue: string) {
    if (filterValue == '') {
      this.tableDataSource = new MatTableDataSource<Element>(this.tableDataSource.data);
      this.tableDataSource.paginator = this.paginator;
    }
  }

  //Filter data in table
  filterValue() {

    if (this.inputFilterModel1 != null) {

      this.inputFilterModel1 = this.inputFilterModel1.trim();
      for (var p = 0; p < this.tableDataSource.data.length; p++) {
        if (this.tableDataSource.data[p][this.uniqueValue] == this.inputFilterModel1) {
          this.tableDataSource.filter = this.inputFilterModel1;
        }
      }
    }

    if (this.inputFilterModel2 != null) {
      this.inputFilterModel2 = this.inputFilterModel2.trim();
      for (var a = 0; a < this.tableDataSource.data.length; a++) {
        if (this.tableDataSource.data[a][this.tableColumnHeader[2]] == this.inputFilterModel2) {
          this.tableDataSource.filter = this.inputFilterModel2;
        }
      }
    }
  }

  //deleting the selected rows in a table
  deleteSelectedRow() {

    this.selection.selected.forEach(item => {
      let index: number = this.tableDataSource.data.findIndex(d => d === item);
      this.tableDataSource.data.splice(index, 1)
      this.tableDataSource = new MatTableDataSource<Element>(this.tableDataSource.data);
    });
    this.tableDataSource.paginator = this.paginator;
    this.selection = new SelectionModel<Element>(true, []);
  }

  //sorthing an array 
  sortingArray(array) {
    array.sort((a: any, b: any) => {
      if (a < b) {
        return -1;
      } else if (a > b) {
        return 1;
      } else {
        return 0;
      }
    });
    return array;
  }
  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.tableDataSource.data.forEach(row => this.selection.select(row));
  }

  //dropdown functions
  shows = [
    { viewValue: 'Show All 25' },
    { viewValue: '1-5 of 25' },
    { viewValue: '6-10 of 25' },
    { viewValue: '11-15 of 25' },
    { viewValue: '16-20 of 25' },
    { viewValue: '21-25 of 25' }
  ];

  ngOnInit() {
    //to prevent back button in browser
    history.pushState(null, null, '');
    window.addEventListener('popstate', function (event) {
      history.pushState(null, null, '');
    });
    this.paginator.pageSize = 5;
    this.tableDataSource.paginator = this.paginator;
  }

  constructor() {
    this.customTableModelBean = new CustomTableModelBean();
  }

}