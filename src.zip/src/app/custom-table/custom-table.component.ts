import { Component, OnInit, ViewChild, Injectable, ChangeDetectorRef } from '@angular/core';
import { MatTableDataSource, MatSort, MatSortHeader, MatSortBase, MatCheckbox, MatPaginator, MatRow, MatColumnDef } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { CDK_TABLE_TEMPLATE } from '@angular/cdk/table';
import { SortFilter } from '../sortFilter.pipe';
import { CustomTableModelBean } from './custom-table-model-bean';
import { Element } from '../system/system.component';

@Component({
  selector: 'app-custom-table',
  templateUrl: './custom-table.component.html',
  styleUrls: ['./custom-table.component.css'],
  inputs: ['uniqueValue', 'inputFilter1', 'inputFilter2', 'tableColumnHeader', 'tableDataSource']
})
export class CustomTableComponent implements OnInit {

  public customTableModelBean: CustomTableModelBean;

  //variables
  tableDataSource = this.tableDataSource;
  tableColumnHeader = this.tableColumnHeader;
  selection = new SelectionModel<Element>(true, []);
  uniqueValue = this.uniqueValue;
  inputFilterModel1;
  inputFilterModel2;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatSortHeader) sortHeader: MatSortHeader;
  @ViewChild(MatColumnDef) column: MatColumnDef;
  @ViewChild(MatCheckbox) myCheckbox: MatCheckbox;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngAfterViewInit() {
    this.sort.start = 'desc';
    this.tableDataSource.matSortChange  = this.sort;
    this.tableDataSource.paginator = this.paginator;
    this.tableDataSource.MatCheckbox = this.myCheckbox;

  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.tableDataSource.data.length;
    return numSelected === numRows;
  }

  alertValue() {
    alert("hi");
  }

  sortColumn(){
      console.log(this.sort);
      this.sort.direction == 'desc';
      this.tableDataSource.sort = this.sort;
  }


  pageView(indexValue){
    if(indexValue != null){
    this.paginator.pageIndex = indexValue;
    this.tableDataSource.paginator = this.paginator;
    }
  }

  pageIndex;
  nextFiveRows(){
    this.pageIndex = this.paginator.pageIndex;
    if(this.pageIndex < this.tableDataSource.data.length/5-1){
    this.paginator.pageIndex = this.pageIndex + 1;
    this.tableDataSource.paginator = this.paginator;
    }
  }


  applyFilter(filterValue: string) {
    if (filterValue == '') {
      this.tableDataSource = new MatTableDataSource<Element>(this.tableDataSource.data);
      this.tableDataSource.paginator = this.paginator;
    }
  }
 
  //Filter data in table
  filterValue() {

    if (this.inputFilterModel1 != null) {

      this.inputFilterModel1 = this.inputFilterModel1.trim();
      for (var p = 0; p < this.tableDataSource.data.length; p++) {
        if (this.tableDataSource.data[p][this.uniqueValue] == this.inputFilterModel1) {
          this.tableDataSource.filter = this.inputFilterModel1;
        }
      }
    }

    if (this.inputFilterModel2 != null) {
      this.inputFilterModel2 = this.inputFilterModel2.trim();
      for (var a = 0; a < this.tableDataSource.data.length; a++) {
        if (this.tableDataSource.data[a][this.tableColumnHeader[2]] == this.inputFilterModel2) {
          this.tableDataSource.filter = this.inputFilterModel2;
        }
      }
    }
  }

  primaryKeyValue: string;
  uniqueValueChecked: string;
  uniqueValueUnChecked: string;
  indexValue = [];
  finalIndexValue = [];
  //store selected row index to delete
  storeSelectedRow(event, checkBoxIndex, selectedRow) {

    this.primaryKeyValue = selectedRow[this.uniqueValue];
    this.tableDataSource.filter.clear;

  // if select All check box is selected
  if(selectedRow == "selectAll"){
    for(var w=0; w<this.tableDataSource.data.length; w++){
      this.indexValue.push(w);
    }
    this.finalIndexValue = this.sortingArray(this.indexValue);
  }

  if(selectedRow!= "selectAll"){
    if (event.checked) {
      for (var i = 0; i < this.tableDataSource.data.length; i++) {
        this.uniqueValueChecked = this.tableDataSource.data[i][this.uniqueValue];
        this.customTableModelBean.setOsLoginValue(this.uniqueValueChecked);
        if (this.customTableModelBean.getOsLoginValue() == this.primaryKeyValue) {
          this.customTableModelBean.setOsLoginValue(null);
          this.indexValue.push(i);
          break;
        }
        this.customTableModelBean.setOsLoginValue(null);
      }
    }
    else {
      for (var j = 0; j < this.indexValue.length; j++) {
        this.uniqueValueUnChecked = this.tableDataSource.data[this.indexValue[j]][this.uniqueValue];
        if (this.uniqueValueUnChecked == this.primaryKeyValue) {
          this.indexValue.splice(j, 1);
          break;
        }
      }
      this.selection.clear;
    }
  }
  this.finalIndexValue = this.sortingArray(this.indexValue);
}

  //deleting the selected rows in a table
  deleteSelectedRow() {
    var a = 0;
    for (var i = 0; i < this.finalIndexValue.length; i++) {
      this.tableDataSource.data.splice(this.finalIndexValue[i] - a, 1);
      this.tableDataSource = new MatTableDataSource<Element>(this.tableDataSource.data);
      this.tableDataSource.paginator = this.paginator;
      a++;
    }
    this.selection.clear();
    this.finalIndexValue.length = 0;
    this.indexValue.length = 0;
    this.uniqueValueChecked = null;
    this.uniqueValueUnChecked = null;
    this.primaryKeyValue = null;
  }

  //sorthing an array 
  sortingArray(array) {
    array.sort((a: any, b: any) => {
      if (a < b) {
        return -1;
      } else if (a > b) {
        return 1;
      } else {
        return 0;
      }
    });
    return array;
  }
  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.tableDataSource.data.forEach(row => this.selection.select(row));
  }

  //dropdown functions
  shows = [
    { viewValue: 'Next5' },
    { viewValue: 'Next10'},
    { viewValue: 'Next15'}
  ];

  ngOnInit() {
     //to prevent back button in browser
     history.pushState(null, null, '');
     window.addEventListener('popstate', function(event) {
     history.pushState(null, null, '');
     });
     this.paginator.pageSize = 5;
     this.tableDataSource.paginator = this.paginator;
   }

  constructor() {
    this.customTableModelBean = new CustomTableModelBean();
  }

}