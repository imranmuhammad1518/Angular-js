import { Component, OnInit, ViewChild, Injectable, ChangeDetectorRef} from '@angular/core';
import {MatTableDataSource, MatSort, MatSortBase, MatCheckbox} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import { UserComponent } from '../user/user.component';
import { CDK_TABLE_TEMPLATE } from '@angular/cdk/table';
import { allSettled } from 'q';

@Component({
  selector: 'app-custom-table',
  templateUrl: './custom-table.component.html',
  styleUrls: ['./custom-table.component.css'],
  inputs: ['inputFilter1','inputFilter2','tableColumnHeader','tableDataSource']
})
export class CustomTableComponent implements OnInit {
  
tableDataSource = this.tableDataSource;
tableColumnHeader= this.tableColumnHeader;
selection = new SelectionModel<Element>(true, []);

@ViewChild(MatSort) sort: MatSort;
@ViewChild('myCheckbox') private myCheckbox: MatCheckbox;

ngAfterViewInit() {
  this.tableDataSource.sort = this.sort;
}

   /** Whether the number of selected elements matches the total number of rows. */
   isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.tableDataSource.data.length;
    return numSelected === numRows;
  }

  alertValue(){
    alert("hi"); 
  }

  inputFilterModel1
  inputFilterModel2;
  //Filter data in table
  filterValue() {
    var inputFilterModel1 = this.inputFilterModel1;
    var inputFilterModel2 = this.inputFilterModel2;

    if(inputFilterModel1 != null){
      inputFilterModel1 = inputFilterModel1.trim();
      inputFilterModel1 = inputFilterModel1.toLowerCase();
      this.tableDataSource.filter = inputFilterModel1;
    }
    if(inputFilterModel2 != null){
      inputFilterModel2 = inputFilterModel2.trim();
    inputFilterModel2 = inputFilterModel2.toLowerCase();
    this.tableDataSource.filter = inputFilterModel2;
    }
  }

  indexValue= [];
    //delete selected row
  selectedRow(event,index)
  { 
     //var  indexValue= [];

    if(event.checked) {
      //this.indexValue.push(index);
      console.log(this.tableDataSource.data[index].OSLogin);
      this.indexValue.push(this.tableDataSource.data[index].OSLogin);
  }
  else{
    alert("unchecked");
    this.indexValue.slice(index);
    event.selection.clear();
  }
  //alert(this.indexValue);
  }

  deleteSelectedRow(){
    //alert(this.tableDataSource.data.length);
     for(var i=0; i<this.tableDataSource.data.length;i++ ){
       //alert(this.tableDataSource.length);
     
      //alert(this.indexValue[i]);
       if(this.indexValue[i] == this.tableDataSource.data[i].OSLogin){

        alert(i);
        //alert(this.tableDataSource.data[i].OSLogin);
       //this.tableDataSource.data.splice(parseInt[i],1);
       //this.tableDataSource = new MatTableDataSource<Element>(this.tableDataSource.data);
       }
    }
    this.tableDataSource = new MatTableDataSource<Element>(this.tableDataSource.data);
  //    for(var i=0; i<this.indexValue.length;i++ ){
  //     this.indexValue.splice(parseInt[i],1);
  //  }
    
     this.selection.clear();
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.tableDataSource.data.forEach(row => this.selection.select(row));
  }

  //dropdown functions
  shows = [
    {viewValue: 'Next5'},
    {viewValue: 'Next10'},
    {viewValue: 'Next15'}
  ];


  ngOnInit() {}

  constructor() {
  }

}