export class CustomTableModelBean {

//creating Variable
  private osLoginValue: string;
  private indexValue: Array<number>;

  // Getters and Setters
  getOsLoginValue() {
    return this.osLoginValue;
  }

  setOsLoginValue(osLoginValue: string) {
    this.osLoginValue = osLoginValue;
  }

}