export class CustomTableModelBean {

//creating Variable
  private osLoginValue: Number;
  private indexValue: Array<number>;

  // Getters and Setters
  getOsLoginValue() {
    return this.osLoginValue;
  }

  setOsLoginValue(osLoginValue: Number) {
    this.osLoginValue = osLoginValue;
  }

}