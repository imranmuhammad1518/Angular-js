import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name : 'ColumnNameFilter'
})

export class  ColumnNameFilterPipe implements PipeTransform{
    transform(columnName: string): string{
        var columnName = columnName.replace(/\s+/g, '');
        if(columnName.includes('/')){
        var columnName = columnName.replace('/','');
        }
        return columnName;
    }
}