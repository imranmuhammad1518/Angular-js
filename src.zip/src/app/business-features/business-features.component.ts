import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {MatTableDataSource} from '@angular/material';

@Component({
  selector: 'app-business-features',
  templateUrl: './business-features.component.html',
  styleUrls: ['./business-features.component.css']
})
export class BusinessFeaturesComponent implements OnInit {

//variables declaration
    hideBusinessConfiguration:boolean = true;
    showAddBusinessConfiguration:boolean;

//table Header
    tableColumnHeader = ['select', 'Function', 'Sub Function1', 'Sub Function2', 'Team Code', 'Errors Enabled','SOD Enabled','For Compliance','Last Updated','Updated By'];
    tableDataSource = new MatTableDataSource<Element>(ELEMENT_DATA);

//dropdown value
  shows = [
    {viewValue: 'Next5'},
    {viewValue: 'Next10'},
    {viewValue: 'Next15'}
  ];

  teamcodelist = [
    'option1',
    'option2',
    'option3'
  ];

//radio button values
  rsiEnabledOrNot=[
    'Yes',
    'No'
  ];
  sodEnabledOrNot=[
    'Yes',
    'No'
  ];
  tablesEnabledOrNot=[
    'Yes',
    'No'
  ];
  
  addBusiness(){
    this.hideBusinessConfiguration = false ;
    this.showAddBusinessConfiguration = true;
  }

  cancelAddBusiness(){
    this.hideBusinessConfiguration = true ;
    this.showAddBusinessConfiguration = false;
  }

  alertValue(){
    alert("action working");
  }

  constructor() {}

  ngOnInit() {}
}

export interface Element {

  Function: string;
  SubFunction1: string;
  SubFunction2: string;
  TeamCode: string;
  ErrorsEnabled: string;
  SODEnabled: string;
  ForCompliance: string;
  LastUpdated: string;
  UpdatedBy: string;
}

const ELEMENT_DATA: Element[] = [
  {Function: '[Function description]1', SubFunction1: '[sub desc fun1]', SubFunction2: '[sub desc fun2]', TeamCode: '[KYC]', ErrorsEnabled: '[NO]', SODEnabled: '[YES]', ForCompliance: '[NO]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {Function: '[Function description]2', SubFunction1: '[sub desc fun1]', SubFunction2: '[sub desc fun2]', TeamCode: '[KYC]', ErrorsEnabled: '[NO]', SODEnabled: '[YES]', ForCompliance: '[NO]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {Function: '[Function description]', SubFunction1: '[sub desc fun1]', SubFunction2: '[sub desc fun2]', TeamCode: '[KYC]', ErrorsEnabled: '[NO]', SODEnabled: '[YES]', ForCompliance: '[NO]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {Function: '[Function description]4', SubFunction1: '[sub desc fun1]', SubFunction2: '[sub desc fun2]', TeamCode: '[KYC]', ErrorsEnabled: '[NO]', SODEnabled: '[YES]', ForCompliance: '[NO]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {Function: '[Function description]5', SubFunction1: '[sub desc fun1]', SubFunction2: '[sub desc fun2]', TeamCode: '[KYC]', ErrorsEnabled: '[NO]', SODEnabled: '[YES]', ForCompliance: '[NO]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {Function: '[Function description]6', SubFunction1: '[sub desc fun1]', SubFunction2: '[sub desc fun2]', TeamCode: '[KYC]', ErrorsEnabled: '[NO]', SODEnabled: '[YES]', ForCompliance: '[NO]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
];