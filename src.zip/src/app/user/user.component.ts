import { Component, OnInit, Injectable, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { CustomTableComponent } from '../custom-table/custom-table.component';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})

export class UserComponent implements OnInit {

  @ViewChild(CustomTableComponent) child: CustomTableComponent;

  //variables declaration
  hideUserConfiguration: boolean = true;
  showAddUserConfiguration: boolean;
  selection = new SelectionModel<Element>(true, []);

  //table header 
  tableColumnHeader = ['select', 'OS Login', 'System', 'Data Hub', 'Site ID', 'RSI Enabled', 'SOD Enabled', 'Tables Enabled', 'Last Updated', 'Updated By'];
  tableDataSource = new MatTableDataSource<Element>(ELEMENT_DATA);

  options = [
    { value: 'option-0', viewValue: 'Option1' },
    { value: 'option-1', viewValue: 'Option2' },
    { value: 'option-2', viewValue: 'Option3' }
  ];

  //radio button values
  rsiEnabledOrNot = [
    'Yes',
    'No'
  ];
  sodEnabledOrNot = [
    'Yes',
    'No'
  ];
  tablesEnabledOrNot = [
    'Yes',
    'No'
  ];


  addUser() {
    this.hideUserConfiguration = false;
    this.showAddUserConfiguration = true;
  }

  cancelUser() {
    this.hideUserConfiguration = true;
    this.showAddUserConfiguration = false;
  }

  alertValue() {
    alert("action working");
  }


  deleteRow() {
    this.child.deleteSelectedRow();
  }


  constructor() { }

  ngOnInit() { 
    //to prevent back button in browser
    history.pushState(null, null, '');
    window.addEventListener('popstate', function(event) {
    history.pushState(null, null, '');
     });
   }
}

export interface Element {

  OSLogin: string;
  System: string;
  DataHub: string;
  SiteID: string;
  RSIEnabled: string;
  SODEnabled: string;
  TablesEnabled: string;
  LastUpdated: string;
  UpdatedBy: string;
}

const ELEMENT_DATA: Element[] = [
  { OSLogin: 'A11', System: '45', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/20', UpdatedBy: 'Gupta Ranjith' },
  { OSLogin: 'A21', System: '12', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/20', UpdatedBy: 'Gupta Ranjith' },
  { OSLogin: '13', System: '89', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith' },
  { OSLogin: '13', System: '65', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith' },
  { OSLogin: '15', System: '78', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith' },
  { OSLogin: '16', System: '23', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith' },
  { OSLogin: '17', System: '65', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith' },
  { OSLogin: '18', System: '78', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith' },
  { OSLogin: '19', System: '23', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith' },
  { OSLogin: '20', System: '65', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith' },
  { OSLogin: '21', System: '78', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith' },
  { OSLogin: '22', System: '23', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith' },
  { OSLogin: '23', System: '65', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith' },
  { OSLogin: '24', System: '78', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith' },
  { OSLogin: '25', System: '23', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith' },
];
