import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {MatTableDataSource} from '@angular/material';


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  //table header 
    tableColumnHeader = ['select','OS Login', 'System', 'Data Hub', 'Site ID', 'RSI Enabled', 'SOD Enabled', 'Tables Enabled', 'Last Updated', 'Updated By'];
    tableDataSource = new MatTableDataSource<Element>(ELEMENT_DATA);

  constructor() { 
    
  }

  ngOnInit() {
  }

  alertValue(){
    alert("action working");
  }

}

export interface Element {

  OSLogin: string;
  System: string;
  DataHub: string;
  SiteID: string;
  RSIEnabled: string;
  SODEnabled: string;
  TablesEnabled: string;
  LastUpdated: string;
  UpdatedBy: string;
}

const ELEMENT_DATA: Element[] = [
  {OSLogin: '[OS Login]1', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[OS Login]2', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[OS Login]3', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[OS Login]4', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[OS Login]5', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[OS Login]6', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
];
