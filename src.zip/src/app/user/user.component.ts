import { Component, OnInit, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import {MatTableDataSource} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';
import { CustomTableComponent } from '../custom-table/custom-table.component';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  //variables declaration
  hideUserConfiguration:boolean = true;
  showAddUserConfiguration:boolean;
  selection = new SelectionModel<Element>(true, []);

  //table header 
  tableColumnHeader = ['select','OS Login', 'System', 'Data Hub', 'Site ID', 'RSI Enabled', 'SOD Enabled', 'Tables Enabled', 'Last Updated', 'Updated By'];
  tableDataSource = new MatTableDataSource<Element>(ELEMENT_DATA);

    options = [
      {value: 'option-0', viewValue: 'Option1'},
      {value: 'option-1', viewValue: 'Option2'},
      {value: 'option-2', viewValue: 'Option3'}
    ];
  
//radio button values
  rsiEnabledOrNot=[
    'Yes',
    'No'
  ];
  sodEnabledOrNot=[
    'Yes',
    'No'
  ];
  tablesEnabledOrNot=[
    'Yes',
    'No'
  ];


    addUser(){
      this.hideUserConfiguration = false ;
      this.showAddUserConfiguration = true;
    }
  
    cancelUser(){
      this.hideUserConfiguration = true ;
      this.showAddUserConfiguration = false;
    }

    alertValue(){
      alert("action working");
    }

    deleteRow(){
    
     var indexArray = JSON.parse(sessionStorage.getItem('session'));
   
      this.tableDataSource.data.splice(parseInt(indexArray),1);
      this.tableDataSource = new MatTableDataSource<Element>(this.tableDataSource.data);
      sessionStorage.clear();
      this.selection.clear();
    }
    constructor() {}

  ngOnInit() {}

}

export interface Element {

  OSLogin: string;
  System: string;
  DataHub: string;
  SiteID: string;
  RSIEnabled: string;
  SODEnabled: string;
  TablesEnabled: string;
  LastUpdated: string;
  UpdatedBy: string;
}

const ELEMENT_DATA: Element[] = [
  {OSLogin: '[zf Login]0', System: '45', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[cd Login]1', System: '12', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[dg Login]2', System: '89', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[et Login]3', System: '65', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[fe Login]4', System: '78', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[ab Login]5', System: '23', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
];
