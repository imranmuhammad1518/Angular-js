import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {MatTableDataSource} from '@angular/material';
import {SelectionModel} from '@angular/cdk/collections';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  highlightedRows = [];
  
  //select All function
  disabled;
  checked;

  selectAll(event){
  
if(!this.checked){
  this.checked = false;
}
  else{
    this.checked = true;
  }
  }

  // selectedCheckBox : number;
  items = [];
  someValue: string;
  selectCheckbox(i, event){
    this.someValue = "checked";
    alert(this.someValue);
    if(this.checked){
      //alert("selected");
      this.items.push(i);
      if(this.items.length == 5 ){
        //alert("coming");
        //this.checked = true;
      }
    }
    else{
      //this.items.splice(i);
      //this.checked = false;
    }
  // }
  }




  selectedRowIndex: number = -1;
  highlight(row){
    console.log(row);
    this.selectedRowIndex = row.id;
    alert(this.selectedRowIndex);
  }

  //display column 
    displayedColumns = ['select','OSLogin', 'System', 'DataHub', 'SiteID', 'RSIEnabled', 'SODEnabled', 'TablesEnabled', 'LastUpdated', 'UpdatedBy'];
    dataSource = new MatTableDataSource<Element>(ELEMENT_DATA);
    selection = new SelectionModel<Element>(true, []);

     /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }


    //dropdown functions
  shows = [
    {viewValue: 'Next5'},
    {viewValue: 'Next10'},
    {viewValue: 'Next15'}
  ];

  constructor() { }

  ngOnInit() {
  }

  alertValue(){
    alert("hi coming");
  }

}

export interface Element {

  OSLogin: string;
  System: string;
  DataHub: string;
  SiteID: string;
  RSIEnabled: string;
  SODEnabled: string;
  TablesEnabled: string;
  LastUpdated: string;
  UpdatedBy: string;
}

const ELEMENT_DATA: Element[] = [
  {OSLogin: '[OS Login]1', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[OS Login]1', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[OS Login]1', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[OS Login]1', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[OS Login]1', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
];
