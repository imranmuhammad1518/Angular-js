import { Component, OnInit, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import {MatTableDataSource} from '@angular/material';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  //variables declaration
  hideUserConfiguration:boolean = true;
  showAddUserConfiguration:boolean;

  //table header 
    tableColumnHeader = ['select','OS Login', 'System', 'Data Hub', 'Site ID', 'RSI Enabled', 'SOD Enabled', 'Tables Enabled', 'Last Updated', 'Updated By'];
    tableDataSource = new MatTableDataSource<Element>(ELEMENT_DATA);

    options = [
      {value: 'option-0', viewValue: 'Option1'},
      {value: 'option-1', viewValue: 'Option2'},
      {value: 'option-2', viewValue: 'Option3'}
    ];
  
//radio button values
  rsiEnabledOrNot=[
    'Yes',
    'No'
  ];
  sodEnabledOrNot=[
    'Yes',
    'No'
  ];
  tablesEnabledOrNot=[
    'Yes',
    'No'
  ];


    addUser(){
      this.hideUserConfiguration = false ;
      this.showAddUserConfiguration = true;
    }
  
    cancelUser(){
      this.hideUserConfiguration = true ;
      this.showAddUserConfiguration = false;
    }

    alertValue(){
      alert("action working");
    }

    public data:any=[];
    constructor() {}

  ngOnInit() {
    // this.storage.set("hi", "hi");
    // this.data["hi"]= this.storage.get("hi");
  }

}

export interface Element {

  OSLogin: string;
  System: string;
  DataHub: string;
  SiteID: string;
  RSIEnabled: string;
  SODEnabled: string;
  TablesEnabled: string;
  LastUpdated: string;
  UpdatedBy: string;
}

const ELEMENT_DATA: Element[] = [
  {OSLogin: '[zf Login]1', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[cd Login]2', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[dg Login]3', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[et Login]4', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[fe Login]5', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {OSLogin: '[ab Login]6', System: '[System description]', DataHub: '[Data Hub]', SiteID: '[KY]', RSIEnabled: '[YES]', SODEnabled: '[YES]', TablesEnabled: '[YES]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
];
