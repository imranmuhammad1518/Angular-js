import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[app-user]',
})

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(public viewContainerRef: ViewContainerRef) { }


  ngOnInit() {
  }

}
