import { Routes,RouterModule } from "@angular/router";
import { ModuleWithProviders } from "@angular/core";

import { LoginFormComponent } from './login-form/login-form.component';
import { BusinessComponent } from './business/business.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { UserComponent } from './user/user.component';

export const router: Routes=[
    {
        path : '',
        component : BusinessComponent
    },
    {
        path : 'user',
        component : UserComponent
    }
    
];

export const routes : ModuleWithProviders = RouterModule.forRoot(router);