import { Routes,RouterModule } from "@angular/router";
import { ModuleWithProviders } from "@angular/core";

import { BusinessComponent } from './business/business.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { UserComponent } from './user/user.component';

export const router: Routes=[
    {
        path : '',
        component : BusinessComponent
    },
    
];

export const routes : ModuleWithProviders = RouterModule.forRoot(router);