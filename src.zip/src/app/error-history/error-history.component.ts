import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material';

@Component({
  selector: 'app-error-history',
  templateUrl: './error-history.component.html',
  styleUrls: ['./error-history.component.css']
})
export class ErrorHistoryComponent implements OnInit {

  //table header
    tableColumnHeader = ['Error Id', 'Error Code', 'Date/Time', 'Phone', 'Extension', 'SOEID', 'Site', 
                          'Channel', 'NICE ID', 'NICE Segment', 'Error Displayed', 'SOD Triggered'];
    tableDataSource = new MatTableDataSource<Element>(ELEMENT_DATA);

  //dropdown functions
  shows = [
    {viewValue: 'Next5'},
    {viewValue: 'Next10'},
    {viewValue: 'Next15'}
  ];

  constructor() { }

  ngOnInit() {
    //to prevent back button in browser
    history.pushState(null, null, '');
    window.addEventListener('popstate', function(event) {
    history.pushState(null, null, '');
    });
  }

  alertValue(){
    alert("action working");
  }

}

export interface Element {

  ErrorId: string;
  ErrorCode: string;
  DateTime: string;
  Phone: string;
  Extension: string;
  SOEID: string;
  Site: string;
  Channel: string;
  NICEID: string;
  NICESegment: string;
  ErrorDisplayed: string;
  SODTriggered: string;
}

const ELEMENT_DATA: Element[] = [
  {ErrorId: '[Error id]1', ErrorCode: '[error code]', DateTime: '[1/19/2018 8:43:12 ET]', 
    Phone: '[9999999]', Extension: '[8888888]', SOEID: '[AB12345]', Site: '[TX]', Channel: '[channel]',
     NICEID: '[NICE ID]', NICESegment: '[87897897887]', ErrorDisplayed:'[Yes]', SODTriggered:'[No]'},

     {ErrorId: '[Error id]2', ErrorCode: '[error code]', DateTime: '[1/19/2018 8:43:12 ET]', 
    Phone: '[9999999]', Extension: '[8888888]', SOEID: '[AB12345]', Site: '[TX]', Channel: '[channel]',
     NICEID: '[NICE ID]', NICESegment: '[87897897887]', ErrorDisplayed:'[Yes]', SODTriggered:'[No]'},

     {ErrorId: '[Error id]3', ErrorCode: '[error code]', DateTime: '[1/19/2018 8:43:12 ET]', 
    Phone: '[9999999]', Extension: '[8888888]', SOEID: '[AB12345]', Site: '[TX]', Channel: '[channel]',
     NICEID: '[NICE ID]', NICESegment: '[87897897887]', ErrorDisplayed:'[Yes]', SODTriggered:'[No]'},

     {ErrorId: '[Error id]4', ErrorCode: '[error code]', DateTime: '[1/19/2018 8:43:12 ET]', 
    Phone: '[9999999]', Extension: '[8888888]', SOEID: '[AB12345]', Site: '[TX]', Channel: '[channel]',
     NICEID: '[NICE ID]', NICESegment: '[87897897887]', ErrorDisplayed:'[Yes]', SODTriggered:'[No]'},

     {ErrorId: '[Error id]5', ErrorCode: '[error code]', DateTime: '[1/19/2018 8:43:12 ET]', 
    Phone: '[9999999]', Extension: '[8888888]', SOEID: '[AB12345]', Site: '[TX]', Channel: '[channel]',
     NICEID: '[NICE ID]', NICESegment: '[87897897887]', ErrorDisplayed:'[Yes]', SODTriggered:'[No]'},
];