import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material';

@Component({
  selector: 'app-system',
  templateUrl: './system.component.html',
  styleUrls: ['./system.component.css']
})
export class SystemComponent implements OnInit {

  highlightedRows = [];

  

  //select All function
  disabled;
  checked;

  selectAll(event){
  
if(!this.checked){
  this.checked = false;
}
  else{
    this.checked = true;
  }
  }

  // selectedCheckBox : number;
  items = [];
  someValue: string;
  selectCheckbox(i, event){
    this.someValue = "checked";
    alert(this.someValue);
    if(this.checked){
      //alert("selected");
      this.items.push(i);
      if(this.items.length == 5 ){
        //alert("coming");
        //this.checked = true;
      }
    }
    else{
      //this.items.splice(i);
      //this.checked = false;
    }
  // }
  }




  selectedRowIndex: number = -1;
  highlight(row){
    console.log(row);
    this.selectedRowIndex = row.id;
    alert(this.selectedRowIndex);
  }

  //display column 
    displayedColumns = ['SelectAll', 'System', 'DataHub', 'LBURL', 'LastUpdated', 'UpdatedBy'];
    dataSource = new MatTableDataSource<Element>(ELEMENT_DATA);

    //dropdown functions
  shows = [
    {viewValue: 'Next5'},
    {viewValue: 'Next10'},
    {viewValue: 'Next15'}
  ];

  constructor() { }

  ngOnInit() {
  }

  alertValue(){
    alert("hi coming");
  }

}

export interface Element {

  SelectAll: string;
  System: string;
  DataHub: string;
  LBURL: string;
  LastUpdated: string;
  UpdatedBy: string;
}

const ELEMENT_DATA: Element[] = [
  {SelectAll: '', System: '[System description]', DataHub: '[Data Hub]', LBURL: '[LB URL Data value]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {SelectAll: '', System: '[System description]', DataHub: '[Data Hub]', LBURL: '[LB URL Data value]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {SelectAll: '', System: '[System description]', DataHub: '[Data Hub]', LBURL: '[LB URL Data value]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {SelectAll: '', System: '[System description]', DataHub: '[Data Hub]', LBURL: '[LB URL Data value]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {SelectAll: '', System: '[System description]', DataHub: '[Data Hub]', LBURL: '[LB URL Data value]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
];

