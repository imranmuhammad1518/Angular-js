import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material';

@Component({
  selector: 'app-system',
  templateUrl: './system.component.html',
  styleUrls: ['./system.component.css']
})
export class SystemComponent implements OnInit {

   //variables declaration
   hideSystemConfiguration:boolean = true;
   showAddSystemConfiguration:boolean;

  //table header 
    tableColumnHeader = ['select', 'System', 'Data Hub', 'LB URL', 'Last Updated', 'Updated By'];
    tableDataSource = new MatTableDataSource<Element>(ELEMENT_DATA);

    //dropdown functions
  shows = [
    {viewValue: 'Next5'},
    {viewValue: 'Next10'},
    {viewValue: 'Next15'}
  ];


  addSystem(){
    this.hideSystemConfiguration = false ;
    this.showAddSystemConfiguration = true;
  }

  cancelAddSystem(){
    this.hideSystemConfiguration = true ;
    this.showAddSystemConfiguration = false;
  }

  alertValue(){
    alert("action working");
  }


  constructor() { }
  ngOnInit() {}

}

export interface Element {

  System: string;
  DataHub: string;
  LBURL: string;
  LastUpdated: string;
  UpdatedBy: string;
}

const ELEMENT_DATA: Element[] = [
  {System: '[System description]1', DataHub: '[Data Hub]', LBURL: '[LB URL Data value]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {System: '[System description]2', DataHub: '[Data Hub]', LBURL: '[LB URL Data value]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {System: '[System description]3', DataHub: '[Data Hub]', LBURL: '[LB URL Data value]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {System: '[System description]4', DataHub: '[Data Hub]', LBURL: '[LB URL Data value]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
  {System: '[System description]5', DataHub: '[Data Hub]', LBURL: '[LB URL Data value]', LastUpdated: '12/05/2018', UpdatedBy: 'Gupta Ranjith'},
];