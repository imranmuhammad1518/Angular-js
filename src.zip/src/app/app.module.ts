import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http'; 
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { routes } from "./app.router";
import { Routes,RouterModule } from "@angular/router";
import { FlexLayoutModule } from "@angular/flex-layout";

import { MatButtonModule,
         MatCardModule,
         MatMenuModule, 
         MatInputModule,
         MatFormFieldModule,
         MatTabsModule,
         MatButtonToggleModule,
         MatTableModule,
         MatGridListModule,
         MatSelectModule,
         MatOptionModule,
         } from '@angular/material';

import { AppComponent } from './app.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { UserComponent } from './user/user.component';
import { BusinessComponent } from './business/business.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginFormComponent,
    FooterComponent,
    HeaderComponent,
    UserComponent,
    BusinessComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatCardModule,
    MatMenuModule,
    MatInputModule,
    MatFormFieldModule,
    MatTabsModule,
    MatButtonToggleModule,
    MatTableModule,
    MatGridListModule,
    FlexLayoutModule,
    MatSelectModule,
    MatOptionModule,
    routes
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
