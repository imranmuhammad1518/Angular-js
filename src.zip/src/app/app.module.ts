import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http'; 
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { routes } from "./app.router";
import { Routes,RouterModule } from "@angular/router";
import { FlexLayoutModule } from "@angular/flex-layout";
import { StorageServiceModule} from 'angular-webstorage-service';

import { MatButtonModule,
         MatCardModule,
         MatMenuModule, 
         MatInputModule,
         MatFormFieldModule,
         MatTabsModule,
         MatButtonToggleModule,
         MatTableModule,
         MatGridListModule,
         MatSelectModule,
         MatOptionModule,
         MatCheckboxModule,
         MatTooltipModule,
         MatPaginatorModule,
         MatSortModule,
         MatRadioModule,
         } from '@angular/material';

import { AppComponent } from './app.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { UserComponent } from './user/user.component';
import { BusinessComponent } from './business/business.component';
import { SystemComponent } from './system/system.component';
import { CustomTableComponent } from './custom-table/custom-table.component';
import { BusinessFeaturesComponent } from './business-features/business-features.component';
import { ErrorsComponent } from './errors/errors.component';
import { ErrorHistoryComponent } from './error-history/error-history.component';
import { ColumnNameFilterPipe } from './columnNameFilter.pipe';
import { SortFilter } from './sortFilter.pipe';


@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HeaderComponent,
    UserComponent,
    BusinessComponent,
    SystemComponent,
    CustomTableComponent,
    BusinessFeaturesComponent,
    ErrorsComponent,
    ErrorHistoryComponent,
    ColumnNameFilterPipe,
    SortFilter
  ],
  imports: [
    BrowserModule,
    HttpModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    StorageServiceModule,
    MatButtonModule,
    MatCardModule,
    MatMenuModule,
    MatInputModule,
    MatFormFieldModule,
    MatTabsModule,
    MatButtonToggleModule,
    MatTableModule,
    MatGridListModule,
    FlexLayoutModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatPaginatorModule,
    MatSortModule,
    MatRadioModule,
    routes
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }