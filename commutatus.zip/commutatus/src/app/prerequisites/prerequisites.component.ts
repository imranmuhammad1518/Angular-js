import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prerequisites',
  templateUrl: './prerequisites.component.html',
  styleUrls: ['./prerequisites.component.css']
})
export class PrerequisitesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
