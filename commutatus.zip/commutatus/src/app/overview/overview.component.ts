import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.css'],
  inputs: ['oppurtunityResponseData']
})
export class OverviewComponent implements OnInit {

  organisationName;
  description;
  
  oppurtunityResponseData = this.oppurtunityResponseData;

  constructor() { }

  ngOnInit() {
    this.organisationName = this.oppurtunityResponseData.branch.organisation.name;
    this.description = this.oppurtunityResponseData.description;
  }

}
