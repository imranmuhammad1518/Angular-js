import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GlobalEntrepreneurComponent } from './global-entrepreneur.component';

describe('GlobalEntrepreneurComponent', () => {
  let component: GlobalEntrepreneurComponent;
  let fixture: ComponentFixture<GlobalEntrepreneurComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GlobalEntrepreneurComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GlobalEntrepreneurComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
