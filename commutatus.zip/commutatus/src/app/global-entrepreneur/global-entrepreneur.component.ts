import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

@Component({
  selector: 'app-global-entrepreneur',
  templateUrl: './global-entrepreneur.component.html',
  styleUrls: ['./global-entrepreneur.component.css'],
  inputs: ['oppurtunityResponseData']
})
export class GlobalEntrepreneurComponent implements OnInit {

  backgroundName:string="";
  earliestStartDate:Date;
  lastEndDate:Date;
  salary:string;
  duration:string;

  salaryValue;

  postUrl:string;

  oppurtunityResponseData = this.oppurtunityResponseData;
  listResponseData;
 
  constructor(private http: HttpClient) {}

  updateValue(){
    //alert(this.backgroundName);
     this.http.patch('http://gisapi-web-staging-1636833739.eu-west-1.elb.amazonaws.com/v2/opportunities/529?access_token=dd0df21c8af5d929dff19f74506c4a8153d7acd34306b9761fd4a57cfa1d483c',
     {
       
       "salary": 5000,
     })
     .subscribe(
      (val) => {
          console.log("PATCH call successful value returned in body", 
                      val);
      },
      response => {
          console.log("PATCH call in error", response);
      },
      () => {
          console.log("The PATCH observable is now completed.");
      });
} 


  ngOnInit() {
    console.log(this.oppurtunityResponseData);
    this.oppurtunityResponseData.backgrounds.forEach(item => {
      if(this.backgroundName==""){
        this.backgroundName = item.name;
      }
      else{
        this.backgroundName = this.backgroundName + ',' + ' ' + item.name;
      }
  });
  
  this.earliestStartDate = this.oppurtunityResponseData.earliest_start_date;
  this.lastEndDate = this.oppurtunityResponseData.latest_end_date;
  this.salary = this.oppurtunityResponseData.specifics_info.salary;
  this.duration = this.oppurtunityResponseData.duration;
  }
}
