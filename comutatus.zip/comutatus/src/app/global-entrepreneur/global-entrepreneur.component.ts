import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-global-entrepreneur',
  templateUrl: './global-entrepreneur.component.html',
  styleUrls: ['./global-entrepreneur.component.css']
})
export class GlobalEntrepreneurComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
