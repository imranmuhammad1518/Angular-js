import { Component, OnInit } from '@angular/core';

import { HttpClient, HttpErrorResponse } from '@angular/common/http';


interface UserResponse {
  title: string;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  url:  string;

  constructor(private http: HttpClient) {
  }

  ngOnInit(): void {
    this.url = 'http://gisapi-web-staging-1636833739.eu-west-1.elb.amazonaws.com/v2/opportunities/529?access_token=dd0df21c8af5d929dff19f74506c4a8153d7acd34306b9761fd4a57cfa1d483c';
    this.http.get<UserResponse>(this.url).subscribe(data => {
      console.log(data);

      // data.branch.forEach(item => {
      //   console.log(item);
      // });
    },

      (err: HttpErrorResponse) => {
        if (err.error instanceof Error) {
          console.log("Client-side-Error Ocurred");
        }
        console.log("server-side-Error Ocurred");
      }

    )
  }

}
