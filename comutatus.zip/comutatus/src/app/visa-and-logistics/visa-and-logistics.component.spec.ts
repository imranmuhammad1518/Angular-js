import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VisaAndLogisticsComponent } from './visa-and-logistics.component';

describe('VisaAndLogisticsComponent', () => {
  let component: VisaAndLogisticsComponent;
  let fixture: ComponentFixture<VisaAndLogisticsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VisaAndLogisticsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VisaAndLogisticsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
