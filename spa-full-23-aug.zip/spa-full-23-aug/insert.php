<?php
include "connectdb.php";
$data= json_decode(file_get_contents("php://input"));

$controllerFinder  = $data->controllerFinder;
if($controllerFinder == "signup"){
	$username = $data->username;
	$password = $data->password;
	$email_id = $data->email_id;
	$phone_no = $data->phone_no;
	
$query = mysql_query("INSERT into user_login VALUES('".$username."','".$password."','".$email_id."',$phone_no)");
}

if($controllerFinder == "employeeDetails"){
	$emp_name = $data->emp_name;
	$emp_designation = $data->emp_designation;
	$emp_projectDetail = $data->emp_projectDetail;
	$emp_location = $data->emp_location;
	$emp_doj = $data->emp_doj;
	$emp_address = $data->emp_address;
	$emp_emailId = $data->emp_emailId;
	$emp_phone = $data->emp_phone;

$query = mysql_query("INSERT into employee_details VALUES('".$emp_name."','".$emp_designation."','".$emp_projectDetail."','".$emp_location."','".$emp_doj."','".$emp_address."','".$emp_emailId."',$emp_phone)");
}



?>