var app = angular.module('angularModule',["ngRoute"]);

app.config(function($routeProvider) {
    $routeProvider
	.when("/", {
		controller: "LoginController",
        templateUrl : "login.html"
    })
    .when("/signUp", {
		controller: "SignupController",
        templateUrl : "sign-up.html"
    })
    .when("/employee", {
		controller: "EmployeeController",
        templateUrl : "employee.html"
    })
	.when("/login", {
		controller: "LoginController",
        templateUrl : "login.html"
    });
});


app.controller('LoginController',['$scope','$http','$location',function($scope,$http,$location){
			
	$scope.getData = function(){
								
	$http.post("select.php",{'login_emailid':$scope.login_emailid})
		
	.then(function(response){
	 $scope.data=response.data
	 localStorage.sharing_username = $scope.data.username
	
			if($scope.data.email_id == $scope.login_emailid && $scope.data.password == $scope.login_password){
				$location.url('/employee');
			}
			else{
				$scope.errorMsg="INVALID CREDENTIALS";
			}
		
	});
	 }
	 
	  $scope.navigateSignup = function() {
	 $location.url('/signUp');
	 } 
	 
}]);

app.controller('EmployeeController',['$scope','$rootScope','$http','$location',function($scope,$rootScope,$http,$location,$window){
    $scope.incoming_msg_value = localStorage.sharing_username

	$scope.Locations = [
			{
				"Id" 		: 1,
				"Name"		: "Siruseri"
			},
			
			{
				"Id" 		: 2,
				"Name"		: "Chennai-one"
			},
			
			{
				"Id" 		: 3,
				"Name"		: "Velachery"
			}
	];
	 
	$scope.signOut = function() {
	 $location.url('/login');
	 } ;
	 
	 $scope.insertEmployeeData = function(){
		$scope.successMsg= "";
		$scope.locationName = $scope.Locations[($scope.emp_location)-1].Name;
		
		 var date = moment($scope.emp_doj).format('YYYY-MM-DD');
		$scope.new_emp_doj = date;
		
		$scope.employeeDetails = "employeeDetails";
		
			$http.post("insert.php",{'controllerFinder':$scope.employeeDetails, 'emp_name':$scope.emp_name,'emp_designation':$scope.emp_designation,'emp_projectDetail':$scope.emp_projectDetail,'emp_location':$scope.locationName,'emp_doj':$scope.new_emp_doj,'emp_address':$scope.emp_address,'emp_emailId':$scope.emp_emailId,'emp_phone':$scope.emp_phone})
			.then(function(response){
				$scope.successMsg="Registration Successful!!";
			
		});
	 }
}]);

app.controller('SignupController',['$scope','$http','$location',function($scope,$http,$location){
	
	$scope.insertdata = function(){
		$scope.errormsg = "";
		$scope.successMsg= "";
		
		$http.post("select.php",{'login_emailid':$scope.login_emailid})
		.then(function(response){
		$scope.data=response.data
		
		$scope.signUpPage = "signup";
		
		if($scope.data.email_id != $scope.login_emailid){
			$http.post("insert.php",{'controllerFinder':$scope.signUpPage,'username':$scope.username, 'password':$scope.password, 'email_id':$scope.login_emailid,'phone_no':$scope.phone_no})
			$scope.successMsg="Registration Successful!!";
			}
			else{
				$scope.errormsg = "Mail Id already Registered, Please enter different mail id";
			}
		});
	 }
	 
	 $scope.backToLogin = function() {
	 $location.url('/login');
	 } ;
	
}]);