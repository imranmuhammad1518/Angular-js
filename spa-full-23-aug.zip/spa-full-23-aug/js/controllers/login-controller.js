app.controller('LoginController',['$scope','$http','$location',function($scope,$http,$location){
			"cache: false"
	$scope.getData = function(){
								
	$http.post("select.php",{'login_emailid':$scope.login_emailid})
		
	.then(function(response){
	 $scope.data=response.data
	 localStorage.sharing_username = $scope.data.username
	//$scope.message = MyFactory.sayHello($scope.data.username);
		
		if($scope.data.email_id == $scope.login_emailid){
			
			$location.url('/index');
		}
		else{
			$scope.errorMsg="INVALID CREDENTIALS";
		}
		
	});
	 }
	 
	 
	  $scope.navigateSignup = function() {
	 $location.url('/signUp');
	 } 
	 
}]);