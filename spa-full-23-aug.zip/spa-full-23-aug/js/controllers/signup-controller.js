app.controller('SignupController',['$scope','$http',function($scope,$http){
	$scope.insertdata = function(){
		
		$http.post("select.php",{'login_emailid':$scope.login_emailid})
		.then(function(response){
		$scope.data=response.data
		
		if($scope.data.email_id != $scope.login_emailid){
			$http.post("insert.php",{'username':$scope.username, 'password':$scope.password, 'email_id':$scope.login_emailid,'phone_no':$scope.phone_no})
			$scope.msg="Registration Successful!!";
			}
			else{
				$scope.Errormsg = "Mail Id already Registered, Please enter different mail id";
			}
		});
	 }
	
}]);