-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2017 at 04:24 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `employee`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee_details`
--

CREATE TABLE IF NOT EXISTS `employee_details` (
  `emp_name` varchar(20) NOT NULL,
  `emp_designation` varchar(20) NOT NULL,
  `emp_projectDetail` varchar(20) NOT NULL,
  `emp_location` varchar(20) NOT NULL,
  `emp_doj` date NOT NULL,
  `emp_address` varchar(50) NOT NULL,
  `emp_emailId` varchar(20) NOT NULL,
  `emp_phone` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_details`
--

INSERT INTO `employee_details` (`emp_name`, `emp_designation`, `emp_projectDetail`, `emp_location`, `emp_doj`, `emp_address`, `emp_emailId`, `emp_phone`) VALUES
('hasna', '1 year exp', 'tailoring', '1', '1993-08-15', 'creation valencia', 'hassy@gmail.com', 2147483647),
('hmj', 'jj', 'hm', 'Chennai-one', '2017-08-04', 'hm', 'hm@hm', 65456456),
('uh', 'h', 'kbhkb', 'Velachery', '1993-05-12', 'gugu', 'igh@guug', 6545646);

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE IF NOT EXISTS `user_login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email_id` varchar(20) NOT NULL,
  `phone_no` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`username`, `password`, `email_id`, `phone_no`) VALUES
('hassy', '1518', 'hassy@gmail.com', '834452400'),
('imran', 'hm', 'hm@gmail.com', '834452'),
('immuhassy', 'immu', 'peppyhassy@gmail.com', '8989798790');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee_details`
--
ALTER TABLE `employee_details`
 ADD PRIMARY KEY (`emp_emailId`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
 ADD PRIMARY KEY (`email_id`), ADD UNIQUE KEY `email_id` (`email_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
