<?php
$data = [{"username":"hm","password":"hm","email_id":"hm@gmail.com","phone_no":"12345678"}];

print json_encode($data);

?>