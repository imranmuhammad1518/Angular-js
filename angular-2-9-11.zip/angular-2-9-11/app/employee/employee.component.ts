import { Component, OnInit } from '@angular/core';
import { IEmployee } from "./employee";
import { EmployeeService } from "./employee.service";

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers: [EmployeeService]
})
export class EmployeeComponent implements OnInit{

  employees = [];
  errorMsg: string;

  constructor(private _employeeService: EmployeeService) { 
  }

  ngOnInit(){
    this._employeeService.getEmployees()
    .subscribe(resEmployeeData => this.employees = resEmployeeData,
          resEmployeeError => this.errorMsg = resEmployeeError);
  }

}
