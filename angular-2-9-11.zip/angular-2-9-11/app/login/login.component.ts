import { Component, OnInit, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
@Injectable()
export class LoginComponent implements OnInit {

  name : String = 'Imran';
  constructor(private _http: Http) { }

  getData = function(){
    
    var emailid = this.emailid;	
    var password = this.password;
   alert(emailid);
   return this._http.post("./insert.php")
        .map((response:Response)=> response.json());
     }

 

  ngOnInit() {
  }

}
