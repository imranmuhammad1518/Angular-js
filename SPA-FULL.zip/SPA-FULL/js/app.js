var app = angular.module('angularModule',["ngRoute"]);

app.config(function($routeProvider) {
    $routeProvider
	.when("/", {
		controller: "LoginController",
        templateUrl : "login.html"
    })
    .when("/signUp", {
		controller: "SignupController",
        templateUrl : "sign-up.html"
    })
    .when("/employee", {
		controller: "EmployeeController",
        templateUrl : "employee.html"
    })
	.when("/login", {
		controller: "LoginController",
        templateUrl : "login.html"
    });
});


app.controller('LoginController',['$scope','$http','$location',function($scope,$http,$location){
			
	$scope.getData = function(){
								
	$http.post("select.php",{'login_emailid':$scope.login_emailid})
		
	.then(function(response){
	 $scope.data=response.data
	 localStorage.sharing_username = $scope.data.username
	//$scope.message = MyFactory.sayHello($scope.data.username);
			
			if($scope.data.email_id == $scope.login_emailid){
				$location.url('/employee');
			}
			else{
				$scope.errorMsg="INVALID CREDENTIALS";
			}
		
	});
	 }
	 
	  $scope.navigateSignup = function() {
	 $location.url('/signUp');
	 } 
	 
}]);

app.controller('EmployeeController',['$scope','$rootScope','$location',function($scope,$rootScope,$location){
    $scope.incoming_msg_value = localStorage.sharing_username

	$scope.locations = [
			{
				"location_id" 		: 1,
				"location_name"		: "Siruseri"
			},
			
			{
				"location_id" 		: 2,
				"location_name"		: "Chennai-one"
			},
			
			{
				"location_id" 		: 3,
				"location_name"		: "Velachery"
			}
	];
	
	$scope.signOut = function() {
	 $location.url('/login');
	 } 
}]);

app.controller('SignupController',['$scope','$http',function($scope,$http){
	$scope.insertdata = function(){
		
		$http.post("select.php",{'login_emailid':$scope.login_emailid})
		.then(function(response){
		$scope.data=response.data
		
		if($scope.data.email_id != $scope.login_emailid){
			$http.post("insert.php",{'username':$scope.username, 'password':$scope.password, 'email_id':$scope.login_emailid,'phone_no':$scope.phone_no})
			$scope.msg="Registration Successful!!";
			}
			else{
				$scope.Errormsg = "Mail Id already Registered, Please enter different mail id";
			}
		});
	 }
	
}]);