import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';

import { routes } from "./app.router";
import { SignupComponent } from './signup/signup.component';
import { EmployeeComponent } from './employee/employee.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    EmployeeComponent
  ],
  imports: [
    [BrowserModule,FormsModule],
    routes
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
