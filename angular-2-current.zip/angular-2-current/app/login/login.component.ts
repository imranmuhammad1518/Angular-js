import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response, Headers } from '@angular/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [Http]
})
export class LoginComponent implements OnInit {

  name : String = 'Imran';

  getData = function(){
    
    var emailid = this.emailid;	
    var password = this.password;
   alert(emailid);
   this.http.post("insert.php",{'controllerFinder':emailid,'login_emailid':password});
     }

  
     routerLink="employee"

  constructor() { }

  ngOnInit() {
  }

}
