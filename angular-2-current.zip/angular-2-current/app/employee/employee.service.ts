import { Injectable } from "@angular/core";
import { IEmployee } from "./employee";

@Injectable()
export class EmployeeService{

    getEmployees(): IEmployee[]{
        return [
        {code: '100', name: 'aaa', gender: 'male', salary: 80000},
        {code: '101', name: 'bbb', gender: 'female', salary: 50000},
        {code: '102', name: 'ccc', gender: 'male', salary: 46000},
        {code: '103', name: 'ddd', gender: 'female', salary: 154000}
        ];
    }
}