import { Component, OnInit } from '@angular/core';

import { IEmployee } from "./employee";
import { EmployeeService } from "./employee.service";

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
  providers: [EmployeeService]
})
export class EmployeeComponent{

  employees: IEmployee[];

  constructor(private _employeeService : EmployeeService) { 
    this.employees = this._employeeService.getEmployees();
  
  }

getTotalEmployeesCount(): number {
  return this.employees.length;
}

}
