import { Routes,RouterModule } from "@angular/router";
import { ModuleWithProviders } from "@angular/core";

import { LoginComponent } from "./login/login.component";
import { SignupComponent } from "./signup/signup.component";
import { EmployeeComponent } from "./employee/employee.component";

export const router: Routes=[
    {
        path : '',
        component : LoginComponent
    },
    {
        path : 'signUp',
        component : SignupComponent
    },
    {
        path: 'backToLogin',
        component : LoginComponent
    },
    {
        path: 'employee',
        component : EmployeeComponent
    }
    
];

export const routes : ModuleWithProviders = RouterModule.forRoot(router);