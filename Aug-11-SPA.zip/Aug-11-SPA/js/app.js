var app = angular.module('angularModule',["ngRoute"]);

app.config(function($routeProvider) {
    $routeProvider
    .when("/sign-up", {
		
		controller: "SignupController",
        templateUrl : "sign-up.html"
    })
    .when("/blue", {
        templateUrl : "blue.html"
    });
});