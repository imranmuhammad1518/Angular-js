app.controller('LoginController',['$scope','$http',function($scope,$http,$routeProvider,$locationProvider){
	
							
	$scope.getData = function(){
								
	$http.post("select.php",{'login_username':$scope.login_username})
		
	.then(function(response){
	 $scope.data=response.data
		
	//$scope.message = MyFactory.sayHello($scope.data.username);
		
		if($scope.data.username == $scope.login_username){
			
			var path = "index.html";
			window.location.href = path;
			localStorage.sharing_username = $scope.data.username
		}
		else{
			$scope.errorMsg="INVALID CREDENTIALS";
		}
		
	});
	 }
	 
}]);