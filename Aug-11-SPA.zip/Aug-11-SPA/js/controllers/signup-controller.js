app.controller('SignupController',['$scope','$http',function($scope,$http){
	
	$scope.insertdata = function(){
	$http.post("insert.php",{'username':$scope.username, 'password':$scope.password, 'email_id':$scope.email_id,'phone_no':$scope.phone_no})

	$scope.msg="Registration Successful!!";
		
	 }
	
}]);