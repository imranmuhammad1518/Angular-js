app.controller('IndexController',['$scope','$rootScope',function($scope,$rootScope){


    $scope.incoming_msg_value = localStorage.sharing_username;

	$scope.locations = [
			{
				"location_id" 		: 1,
				"location_name"		: "Siruseri"
			},
			
			{
				"location_id" 		: 2,
				"location_name"		: "Chennai-one"
			},
			
			{
				"location_id" 		: 3,
				"location_name"		: "Velachery"
			}
	];
	
}]);