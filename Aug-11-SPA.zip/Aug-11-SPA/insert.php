<?php
include "connectdb.php";
$data= json_decode(file_get_contents("php://input"));
$username = $data->username;
$password = $data->password;
$email_id = $data->email_id;
$phone_no = $data->phone_no;

$query = mysql_query("INSERT into user_login VALUES('".$username."','".$password."','".$email_id."',$phone_no)");


?>