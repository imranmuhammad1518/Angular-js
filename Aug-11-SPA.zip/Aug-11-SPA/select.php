<?php
include "connectdb.php";

$data= json_decode(file_get_contents("php://input"));

$login_username = $data->login_username;

$query=mysql_query("SELECT * FROM `user_login` WHERE username='$login_username'");
$data = mysql_fetch_assoc($query);

print json_encode($data);

?>


