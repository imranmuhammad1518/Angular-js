var app = angular.module('angularModule',["ngRoute"]);

app.config(function($routeProvider) {
    $routeProvider
	.when("/", {
		controller: "LoginController",
        templateUrl : "login.html"
    })
    .when("/signUp", {
		controller: "SignupController",
        templateUrl : "sign-up.html"
    })
    .when("/employee", {
		controller: "EmployeeController",
        templateUrl : "employee.html"
    })
	.when("/addEmployee", {
		controller: "AddEmployee",
        templateUrl : "addEmployee.html"
    })
	.when("/editEmployee", {
		controller: "EditEmployee",
        templateUrl : "editEmployee.html"
    })
	.when("/searchEmployee", {
		controller: "SearchEmployee",
        templateUrl : "searchEmployee.html"
    })
	.when("/deleteEmployee", {
		controller: "DeleteEmployee",
        templateUrl : "deleteEmployee.html"
    })
	.when("/login", {
		controller: "LoginController",
        templateUrl : "login.html"
    });
});