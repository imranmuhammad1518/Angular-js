app.controller('SignupController',['$scope','$http','$location',function($scope,$http,$location){
	
	$scope.insertdata = function(){
		$scope.errormsg = "";
		$scope.successMsg= "";
		$scope.signUpPage = "userTableReference";
		
		$http.post("select.php",{'controllerFinder':$scope.signUpPage,'login_emailid':$scope.login_emailid})
		.then(function(response){
		$scope.data=response.data
		
		if($scope.data.email_id != $scope.login_emailid){
			$http.post("insert.php",{'controllerFinder':$scope.signUpPage,'username':$scope.username, 'password':$scope.password, 'email_id':$scope.login_emailid,'phone_no':$scope.phone_no})
			$scope.successMsg="Registration Successful!!";
			}
			else{
				$scope.errormsg = "Mail Id already Registered, Please enter different mail id";
			}
		});
	 }
	 
	 $scope.backToLogin = function() {
	 $location.url('/login');
	 } ;
	
}]);