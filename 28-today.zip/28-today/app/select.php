<?php
include "connectdb.php";
$data= json_decode(file_get_contents("php://input"));

$controllerFinder  = $data->controllerFinder;

if($controllerFinder == "userTableReference"){
$login_emailid = $data->login_emailid;

$query=mysql_query("SELECT * FROM `user_login` WHERE email_id='$login_emailid'");
$data = mysql_fetch_assoc($query);

print json_encode($data);
}

if($controllerFinder == "employeeDetails"){
	
	$emp_empId = $data->emp_empId;
	
$query=mysql_query("SELECT * FROM `employee_details` WHERE emp_id='$emp_empId'");
$data = mysql_fetch_assoc($query);

print json_encode($data);
}
	
	
	
	
?>


