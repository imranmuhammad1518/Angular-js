<?php
include "connectdb.php";
$data= json_decode(file_get_contents("php://input"));	

$controllerFinder  = $data->controllerFinder;

if($controllerFinder == "ContactDetailsReference"){
$phone_no = $data->phone_no;

$query=mysql_query("SELECT * FROM `user_data` WHERE ph_no='$phone_no'");
$data = mysql_fetch_assoc($query);
print json_encode($data);
}

if($controllerFinder == "homePageContents"){
$query=mysql_query("SELECT * FROM `page_contents` WHERE ph_no='8344524069'");
$data = mysql_fetch_assoc($query);
print json_encode($data);
}	
	
?>


