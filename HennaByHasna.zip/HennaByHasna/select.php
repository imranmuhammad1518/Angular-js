<?php
include "connectdb.php";
$data= json_decode(file_get_contents("php://input"));	

$query=mysql_query("SELECT * FROM `page_contents` WHERE ph_no='8344524069'");
$data = mysql_fetch_assoc($query);

print json_encode($data);
	
	
?>


