app.directive('channelLogo',function(){
	
	return{
		restrict : "EA",
		template : function(element,attribute){
			
			return "<img src='images/imran.jpg'/>";
		}
	}
	
});
