app.controller('ServiceController',['$scope','$location','$mdDialog','$mdMedia',function($scope,$location,$mdDialog,$mdMedia){

//big Dialog ng material
	 $scope.showAdvanced = function(ev) {
	
	//session to pass selected image to md-dialog
	 
     $mdDialog.show({
      controller: 'ServiceController',
	  locals:{dataToPass: $scope.parentScopeData},
	  controllerAs: 'ctrl',	  
      templateUrl: 'booking-dialog.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:true
    })
  };
  
  $scope.renderPersonalDetails = function(){
	  $scope.packageDetails = false;
  $scope.personalDetails = localStorage.personalDetails;
   };
  
$scope.renderPackageInfo = function(){
  $scope.personalDetails = false;
  $scope.packageDetails = true;
   };
   
  $scope.closeDialog = function(){
	  
	  localStorage.personalDetails = ''
	 localStorage.personalDetails = "true";
      $mdDialog.hide(close);
	 };
  
  }]);