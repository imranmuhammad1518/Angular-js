app.controller('SignupController',['$rootScope','$scope','$http','$location',function($rootScope,$scope,$http,$location){
	
	$scope.insertdata = function(){
		$scope.errormsg = "";
		$scope.successMsg= "";
		
		$scope.signUpPage = "userTableReference";
		
		$http.post("select.php",{'controllerFinder':$scope.signUpPage,'login_emailid':$scope.login_emailid})
		.then(function(response){
		$scope.data=response.data
		
		if($scope.data.email_id != $scope.login_emailid){
			$http.post("insert.php",{'controllerFinder':$scope.signUpPage,'username':$scope.user_username, 'password':$scope.user_password, 'email_id':$scope.login_emailid,'phone_no':$scope.phone_no})
			$scope.successMsg="Registration Successful!!";
			}
			else{
				$scope.errormsg = "Mail Id already Registered, Please enter different mail id";
			}
		});
	 }
	 
	 $scope.backToLogin = function() {
	 $location.url('/login');
	 };
	 
	 $scope.resetAll = function(){ 
		$scope.user_username = null;
		$scope.user_password = null;
		$scope.retypePassword = null;
		$scope.login_emailid = null;
		$scope.phone_no = null;
		$scope.errormsg = null;
	};
	
	$rootScope.$on('$locationChangeSuccess', function(event, toState, toParams, fromState, fromParams) {
	 event.preventDefault();
      window.history.forward();
    });
	
}]);