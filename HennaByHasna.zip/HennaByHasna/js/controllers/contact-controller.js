app.controller('ContactController',['$scope','$location','$http','$mdDialog','$window',function($scope,$location,$http,$mdDialog,$window){

	var w = window.innerWidth;
    var h = window.innerHeight;
	
	if(w > 768){
		$scope.sizeValue = "width:20%;";
	}
	else{
		$scope.sizeValue = "width:75%;";
	}
	
	$(window).resize(function(){
    //alert(window.innerWidth);
    $scope.$apply(function(){
       
	var resizeWidth = window.innerWidth;
    var resizeHeight = window.innerHeight;
	
	if(resizeWidth > 768){
		$scope.sizeValue = "width:20%;";
	}
	else{
		$scope.sizeValue = "width:75%;";
	}
	   });
	});

$scope.showAlert = function(ev){
		
		$scope.contactDetails = "ContactDetailsReference";	
		//alert($scope.phone_no);
		$http.post("select.php",{'controllerFinder':$scope.contactDetails,'phone_no':$scope.phone_no})
		.then(function(response){
		$scope.data=response.data
		
		if($scope.data.ph_no != $scope.phone_no){
			$http.post("insert.php",{'controllerFinder':$scope.contactDetails,'cus_name':$scope.customer_name, 'cus_email':$scope.customer_email, 'cus_phno':$scope.phone_no,'add_info':$scope.add_info})
			
				$mdDialog.show(
				$mdDialog.alert()
				.parent(angular.element(document.querySelector('#popupContainer')))
				.clickOutsideToClose(true)
				.title('Thanks for contacting !')
				.textContent('Henna By Hasna will get back to you shortly..')
				.ariaLabel('Alert Dialog Demo')
				.ok('Okay!')
				.targetEvent(ev)  );
			
			}
			else{
				
				$mdDialog.show(
				$mdDialog.alert()
				.parent(angular.element(document.querySelector('#popupContainer')))
				.clickOutsideToClose(true)
				.title('You have already contacted us..')
				.textContent('Henna By Hasna will get back to you shortly.Thanks for your patience !!')
				.ariaLabel('Alert Dialog Demo')
				.ok('Okay!')
				.targetEvent(ev)  );
			  }
			
		});
		
  };


  }]);