app.controller('ContactController',['$scope','$location',function($scope,$location){


  }]);