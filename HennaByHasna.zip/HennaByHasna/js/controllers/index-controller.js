app.controller('IndexController',['$rootScope','$scope','$http','$location','$timeout',function($rootScope,$scope,$http,$location,$timeout){
	
		$scope.processing = true;
			$timeout(function(){
			$scope.processing = false;
			},2000);
		
		
		$scope.facebookPage = function(){
			
			window.open("https://www.facebook.com/hennabyhasna/");	
		}
		
		$scope.pinterestPage = function(){
			
			window.open("https://pin.it/egmengkqdr4ygc");	
		}

		$scope.googlePlusPage = function(){
			
			//window.open("");	
		}
		
		$scope.instagramPage = function(){
			
			window.open("https://www.instagram.com/hennabyhasna/");	
		}

		$scope.youtubePage = function(){
			
			window.open("https://www.youtube.com/channel/UCGEsvrBo8SJBMdk3cgpSu_w");	
		}
}]);