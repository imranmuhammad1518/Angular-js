app.controller('IndexController',['$rootScope','$scope','$http','$location','$timeout',function($rootScope,$scope,$http,$location,$timeout){
	
		$scope.processing = true;
			$timeout(function(){
			$scope.processing = false;
			},2000);
		
	var w = window.innerWidth;
    var h = window.innerHeight;
	$scope.showHomePage = false;
	$scope.showPortfolioPage = false;
	$scope.showServicePage = false;
	$scope.showContactPage = false;
	
	if(w < 768){
		$scope.showHomePage = true;
	}
	
	$(window).resize(function(){
    //alert(window.innerWidth);
    $scope.$apply(function(){
       
	var resizeWidth = window.innerWidth;
    var resizeHeight = window.innerHeight;
	
	if(resizeWidth < 768){
		$scope.showHomePage = true;
	}
	   });
	});
		
		$scope.openHomePage = function(){
			$scope.showHomePage = true;
			$scope.showPortfolioPage = false;
			$scope.showServicePage = false;
			$scope.showContactPage = false;
		}
		
		$scope.openPortfolioPage = function(){
			$scope.showPortfolioPage = true;
			$scope.showHomePage = false;
			$scope.showServicePage = false;
			$scope.showContactPage = false;
		}
		
		$scope.openServicePage = function(){
			$scope.showServicePage = true;
			$scope.showHomePage = false;
			$scope.showPortfolioPage = false;
			$scope.showContactPage = false;
		}
		
		$scope.openContactPage = function(){
			$scope.showContactPage = true;
			$scope.showHomePage = false;
			$scope.showPortfolioPage = false;
			$scope.showServicePage = false;
		}
	
	
	
		$scope.facebookPage = function(){
			
			window.open("https://www.facebook.com/hennabyhasna/");	
		}
		
		$scope.pinterestPage = function(){
			
			window.open("https://pin.it/egmengkqdr4ygc");	
		}

		$scope.googlePlusPage = function(){
			
			//window.open("");	
		}
		
		$scope.instagramPage = function(){
			
			window.open("https://www.instagram.com/hennabyhasna/");	
		}

		$scope.youtubePage = function(){
			
			window.open("https://www.youtube.com/channel/UCGEsvrBo8SJBMdk3cgpSu_w");	
		}
}]);