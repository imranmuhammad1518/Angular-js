app.controller('IndexController',['$rootScope','$scope','$http','$location','$timeout',function($rootScope,$scope,$http,$location,$timeout){
	
			$scope.processing = true;
				$timeout(function(){
				$scope.processing = false;
				},1500);
		
	$scope.homePage = function(){
			$scope.processing = true;
				$timeout(function(){
				$scope.processing = false;
				},1500);
		  
				$timeout(function(){
				 $location.url('/');
				},1500);
	 };
	 
	 
	 $scope.portfolioPage = function(){
			$scope.processing = true;
				$timeout(function(){
				$scope.processing = false;
				},1500);
		  
				$timeout(function(){
				 $location.url('/portfolio');
				},1500);
	 };
	 
	 
	 $scope.servicePage = function(){
			$scope.processing = true;
				$timeout(function(){
				$scope.processing = false;
				},1500);
		  
				$timeout(function(){
				 $location.url('/service');
				},1500);
	 };
	 
	 $scope.contactPage = function(){
			$scope.processing = true;
				$timeout(function(){
				$scope.processing = false;
				},1500);
		  
				$timeout(function(){
				 $location.url('/contact');
				},1500);
	 };
}]);