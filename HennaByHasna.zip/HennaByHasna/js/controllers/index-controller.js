app.controller('IndexController',['$rootScope','$scope','$http','$location','$timeout',function($rootScope,$scope,$http,$location,$timeout){
	
		$scope.processing = true;
			$timeout(function(){
			$scope.processing = false;
			},2000);
				
		$scope.launchContact=false;
		$scope.launchService=false;
		$scope.launchPortfolio=false;
		
	$scope.homePage = function(){
		$scope.processing = true;
		
		$scope.launchContact=false;
		$scope.launchService=false;
		$scope.launchPortfolio=false;
		
				$timeout(function(){
				$scope.launchHome=true;
				$scope.processing = false;
				 $location.url('/');
				},2000);
	 };
	 
	 
	 $scope.portfolioPage = function(){
		$scope.processing = true;
		
		$scope.launchContact=false;
		$scope.launchService=false;
		$scope.launchHome=false;
		  
				$timeout(function(){
				$scope.launchPortfolio=true;
				$scope.processing = false;
				 $location.url('/portfolio');
				},2000);
	 };
	 
	 
	 $scope.servicePage = function(){
		$scope.processing = true;
		
		$scope.launchContact=false;
		$scope.launchPortfolio=false;
		$scope.launchHome=false;
		 
				$timeout(function(){
				$scope.launchService=true;
				$scope.processing = false;
				 $location.url('/service');
				},2000);
	 };
	 
	 $scope.contactPage = function(){
		$scope.processing = true;
		
		$scope.launchService=false;
		$scope.launchPortfolio=false;
		$scope.launchHome=false;
		 
				$timeout(function(){
					$scope.launchContact=true;
					$scope.processing = false;
				 $location.url('/contact');
				},2000);
	 };
}]);