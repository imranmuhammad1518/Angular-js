app.controller('IndexController',['$rootScope','$scope','$http','$location','$timeout',function($rootScope,$scope,$http,$location,$timeout){
	
		$scope.processing = true;
			$timeout(function(){
			$scope.processing = false;
			},2000);
		
	$scope.homePage = function(){
		$location.url('/');
	 };
	 
	 $scope.portfolioPage = function(){
		$location.url('/portfolio');
	 };
	 
	 $scope.servicePage = function(){
		$location.url('/service');
	 };
	 
	 $scope.contactPage = function(){
		$location.url('/contact');
	 };
}]);