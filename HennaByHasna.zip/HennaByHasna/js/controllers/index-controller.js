app.controller('IndexController',['$rootScope','$scope','$http','$location',function($rootScope,$scope,$http,$location){
	
		
		
	$scope.homePage = function(){
	 $location.url('/');
	 };
	 
	 $scope.galleryPage = function(){
	 $location.url('/galleryPage');
	 };
}]);