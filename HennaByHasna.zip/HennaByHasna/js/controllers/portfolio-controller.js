app.controller('PortfolioController',['$scope','$location','$mdDialog','$mdMedia',function($scope,$location,$mdDialog,$mdMedia){
	
	 
	  $scope.images = [
	  { "id"   : 0,
		"src"  : "images/portfolio-image1.jpg",
		"desc" : "Bride Henna Design"
	  },
	  { "id" : 1,
		"src" : "images/portfolio-image2.jpg",
		"desc" : "Birthday Party Henna Design"
	  },
	  { "id" : 2,
		"src" : "images/home-image3.jpg",
		"desc" : "Guests Henna Design"
	  }
  ];
  
 
 var modal = document.getElementById('myModal');

// Get the image and insert it inside the modal - use its "alt" text as a caption
var img = document.getElementById('myImg');
var modalImg = document.getElementById("showImage");
var captionText = document.getElementById("caption");

$scope.openImage = function(ev,index){
	
    modal.style.display = "block";
    modalImg.src = $scope.images[index].src;
    captionText.innerHTML = $scope.images[index].desc;
}

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() { 
    modal.style.display = "none";
} 
	
	 
}]);