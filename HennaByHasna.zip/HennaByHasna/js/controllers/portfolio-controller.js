app.controller('PortfolioController',['$scope','$location','$mdDialog','$mdMedia',function($scope,$location,$mdDialog,$mdMedia){
	
	
	 $scope.images1 = [
	  { "id"   : 0,
		"src"  : "images/portfolio-image10.jpg",
		"desc" : "Bride Henna Design"
	  },
	  { "id"   : 1,
		"src"  : "images/portfolio-image5.jpg",
		"desc" : "Birthday Party Henna Design"
	  },
	  { "id"   : 2,
		"src"  : "images/portfolio-image6.jpg",
		"desc" : "Guests Henna Design"
	  },
	  { "id"   : 3,
		"src"  : "images/guest-mehandhi.jpg",
		"desc" : "Guests Henna Design"
	  },
	  { "id"   : 4,
		"src"  : "images/portfolio-image1.jpg",
		"desc" : "Guests Henna Design"
	  },
	   { "id"   : 5,
		"src"  : "images/portfolio-image14.jpg",
		"desc" : "Bride Henna Design"
	  },
	  { "id"   : 6,
		"src"  : "images/portfolio-image18.jpg",
		"desc" : "Birthday Party Henna Design"
	  },
	  { "id"   : 7,
		"src"  : "images/portfolio-image3.jpg",
		"desc" : "Guests Henna Design"
	  },
	  { "id"   : 8,
		"src"  : "images/portfolio-image2.jpg",
		"desc" : "Guests Henna Design"
	  },
	  { "id"   : 9,
		"src" : "images/portfolio-image12.jpg",
		"desc" : "Guests Henna Design"
	  },
	   { "id"   : 10,
		"src"  : "images/home-image3.jpg",
		"desc" : "Bride Henna Design"
	  },
	  { "id"   : 11,
		"src" : "images/portfolio-image8.jpg",
		"desc" : "Birthday Party Henna Design"
	  }
  ];
  
  
    this.tiles = buildGridModel({
            title: "Image-",
            background: ""
          });

    function buildGridModel(tileTmpl){
      var it, results = [ ];

      for (var j=0; j<11; j++) {

        it = angular.extend({},tileTmpl);
        it.icon  = it.icon + (j+1);
        it.title = it.title + (j+1);
        it.span  = { row : 1, col : 1 };

        switch(j+1) {
          case 1:
            it.background = "red";
            it.span.row = it.span.col = 2;
            break;

          case 2: it.background = "red";         break;
          case 3: it.background = "red";      break;
          case 4:
            it.background = "red";
            it.span.col = 2;
            break;

          case 5:
            it.background = "red";
            it.span.row = it.span.col = 2;
            break;

          case 6: it.background = "red";          break;
          case 7: it.background = "red";      break;
          case 8: it.background = "red";        break;
          case 9: it.background = "red";      break;
          case 10: it.background = "red";  break;
          case 11: it.background = "red";       break;
        }

        results.push(it);
      }
      return results;
    }
	
	 var modal = document.getElementById('myModal');

// Get the image and insert it inside the modal - use its "alt" text as a caption
var img = document.getElementById('myImg');
var modalImg = document.getElementById("showImage");
var captionText = document.getElementById("caption");

	$scope.imageStyle = {
	"border-radius" : "5px",
    "cursor"		: "pointer",
    "transition"	: "0.3s",
	}
	$scope.showCloseButtton = false;
	
$scope.openImage = function(index,arrayImageNumber){

	$scope.showCloseButtton = true;
	
	$scope.modal = {
	"display"		   : "block",
    "position"         : "fixed",
    "z-index"          : "1",
    "padding-top" 	   : "100px",
    "left"        	   : "0",
    "top" 		       : "0",
    "width" 	  	   : "100%",
    "height"	  	   : "100%",
    "overflow"    	   : "auto",
    "background-color" : "rgb(0,0,0)",
    "background-color" : "rgba(0,0,0,0.9)",
	"from-transform":"scale(0)",
	"from-transform":"scale(1)"
	}
	
	$scope.modalContent = {
	"margin"	: "auto",
    "display"	: "block",
    "width"		: "100%",
    "max-width" : "700px"
	}
	
	$scope.closeImage = {	
	"position"        : "absolute",
    "top"	          : "15px",
    "right"	          : "35px",
    "color"	          : "#f1f1f1",
    "font-size"       : "40px",
    "font-weight"     : "bold",
    "transition"      : "0.3s",
	"color" 		  : "#bbb",
    "text-decoration" : "none",
    "cursor"		  : "pointer"
	}
	
  if(arrayImageNumber == 1){
    $scope.modal_Img = $scope.images1[index].src;
    $scope.captionText = $scope.images1[index].desc;
	}
}

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
$scope.closeModalImage = function() { 

   $scope.showCloseButtton = "false";
   $scope.modal = {"display": "none"}
} 


  }]);
  

  
	