app.controller('PortfolioController',['$scope','$location','$mdDialog','$mdMedia',function($scope,$location,$mdDialog,$mdMedia){
	
	
	$scope.homePage = function(){
	 $location.url('/');
	 };
	 
	  $scope.images = [
	  { "id" : 0,
		"src" : "images/image1.jpg"
	  },
	  { "id" : 1,
		"src" : "images/image3.jpg"
	  },
	  { "id" : 2,
		"src" : "images/has.jpg"
	  },
	  { "id" : 3,
		"src" : "images/image4.jpg"
	  }
  ];
  
  

  
  
	 //big Dialog ng material
	 $scope.showAdvanced = function(ev,index) {
	
	//session to pass selected image to md-dialog
	 localStorage.selected_image = ''
	 localStorage.selected_image = $scope.images[index].src
	
     $mdDialog.show({
      controller: 'DialogController',
	  locals:{dataToPass: $scope.parentScopeData},
	  controllerAs: 'ctrl',	  
      templateUrl: 'portfolio-image-view-dialog.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:false
    })
  };
	 
}]);