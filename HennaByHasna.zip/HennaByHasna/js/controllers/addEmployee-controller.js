app.controller('AddEmployee',['$scope','$rootScope','$http','$location',function($scope,$rootScope,$http,$location,$window){

	$scope.Locations = [		
						{
							"Id" 		: 1,
							"Name"		: "Siruseri"
						},
						
						{
							"Id" 		: 2,
							"Name"		: "Chennai-one"
						},
						
						{
							"Id" 		: 3,
							"Name"		: "Velachery"
						}
	];
	 
	$scope.backToEmployee = function() {
	 $location.url('/employee');
	 } ;
	 
	 $scope.insertEmployeeData = function(){
		$scope.successMsg= "";
		$scope.errorMsg="";
		if(($scope.Locations[($scope.emp_location)-1].Name)!= "Select"){
		$scope.locationName = $scope.Locations[($scope.emp_location)-1].Name;
		}
		 var date = moment($scope.emp_doj).format('YYYY-MM-DD');
		$scope.new_emp_doj = date;
		$scope.employeeDetails = "employeeDetails";
			$http.post("select.php",{'controllerFinder':$scope.employeeDetails,'emp_empId':$scope.emp_empId})
			.then(function(response){
			$scope.data=response.data
		
			if($scope.data.emp_id != $scope.emp_empId){
			$http.post("insert.php",{'controllerFinder':$scope.employeeDetails, 'emp_name':$scope.emp_name,'emp_empId':$scope.emp_empId,'emp_designation':$scope.emp_designation,'emp_projectDetail':$scope.emp_projectDetail,'emp_location':$scope.locationName,'emp_doj':$scope.new_emp_doj,'emp_address':$scope.emp_address,'emp_emailId':$scope.emp_emailId,'emp_phone':$scope.emp_phone})
		    $scope.successMsg="Employee Details Added Successfully!!";
			}
			else{
				$scope.errorMsg="Employee Id already Registered..";
			}
		});
	 };
	 
	 $scope.resetAll = function(){ 
		$scope.successMsg= "";
		$scope.errorMsg="";
		$scope.emp_name = null;
		$scope.emp_empId = null;
		$scope.emp_designation = null;
		$scope.emp_projectDetail = null;
		$scope.emp_location = null;
		$scope.emp_doj = null;
		$scope.emp_address = null;
		$scope.emp_emailId = null;
		$scope.emp_phone = null;
	};
}]);