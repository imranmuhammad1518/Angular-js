app.controller('HomeController',['$rootScope','$scope','$http','$location','$window',function($rootScope,$scope,$http,$location,$window){
	
		
		$scope.homePageContents = "homePageContents";
		
		 $http.post("select.php",{'controllerFinder':$scope.homePageContents})		
		 .then(function(response){
		  $scope.data=response.data
			//alert($scope.data.ph_no);
			$scope.aboutInfo  =  $scope.data.about_info 
			$scope.byInfo 	  =  $scope.data.by_info
			$scope.aboutHenna =  $scope.data.abt_henna
		 });

 $scope.includeDesktopTemplate = false;
$scope.includeMobileTemplate = false; 
var screenWidth = $window.innerWidth;

if (screenWidth < 960){
    $scope.includeMobileTemplate = true;
}else{
    $scope.includeDesktopTemplate = true;
}

    $scope.dataArray = [
      {
        src: 'images/home-image1.jpg'
      },
      
      {
        src: 'images/home-image2.jpg'
      },
	  
      {
        src: 'images/home-image3.jpg'
      }
    ];
	 
}]);