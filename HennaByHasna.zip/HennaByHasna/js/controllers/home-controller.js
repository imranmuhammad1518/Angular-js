app.controller('HomeController',['$rootScope','$scope','$http','$location',function($rootScope,$scope,$http,$location){
	
		
		 $http.post("select.php")		
		 .then(function(response){
		  $scope.data=response.data
			//alert($scope.data.ph_no);
			$scope.aboutInfo  =  $scope.data.about_info 
			$scope.byInfo 	  =  $scope.data.by_info
		 });

    $scope.dataArray = [
      {
        src: 'images/image1.jpg'
      },
      
      {
        src: 'images/image3.jpg'
      },
	  
      {
        src: 'images/image4.jpg'
      }
    ];
	
	$scope.galleryPage = function(){
	 $location.url('/galleryPage');
	 };
	 
}]);