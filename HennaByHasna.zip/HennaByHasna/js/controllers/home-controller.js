app.controller('HomeController',['$rootScope','$scope','$http','$location',function($rootScope,$scope,$http,$location){
	
		
		 $http.post("select.php")		
		 .then(function(response){
		  $scope.data=response.data
			//alert($scope.data.ph_no);
			$scope.aboutInfo  =  $scope.data.about_info 
			$scope.byInfo 	  =  $scope.data.by_info
		 });

    $scope.dataArray = [
      {
        src: 'images/home-image1.jpg'
      },
      
      {
        src: 'images/home-image2.jpg'
      },
	  
      {
        src: 'images/home-image3.jpg'
      }
    ];
	
	$scope.galleryPage = function(){
	 $location.url('/galleryPage');
	 };
	 
}]);