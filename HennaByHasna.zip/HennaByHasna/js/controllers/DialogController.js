app.controller('DialogController',['$scope','$location','$mdDialog','$mdMedia',function($scope,$location,$mdDialog,$mdMedia, dataToPass){

 $scope.open_Selected_Image = localStorage.selected_image
 
    $scope.hide = function() {
      $mdDialog.hide();
    };

    $scope.cancel = function() {
      $mdDialog.cancel();
    };

    $scope.close = function(close) {
	  localStorage.selected_image = ''
      $mdDialog.hide(close);
    };

  }]);