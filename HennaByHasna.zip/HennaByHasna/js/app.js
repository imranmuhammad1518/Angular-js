// Code goes here

var app = angular.module('myApp', ['ngRoute','ngMaterial', 'jkAngularCarousel'])

app.config(function($routeProvider) {
    $routeProvider
	.when("/", {
		controller: "IndexController",
        templateUrl : "index.html"
     });
});