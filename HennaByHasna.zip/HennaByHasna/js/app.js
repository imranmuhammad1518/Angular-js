var app = angular.module('HennaByHasna', ['ngRoute','ngMaterial','ngMdIcons','jkAngularCarousel'])

app.config(function($routeProvider) {
    $routeProvider
	 .when("/", {
		controller: "HomeController",
        templateUrl : "home.html"
     })
	 
	 .when("/galleryPage", { 
		controller: "GalleryController",
        templateUrl : "gallery.html"
     });  
});