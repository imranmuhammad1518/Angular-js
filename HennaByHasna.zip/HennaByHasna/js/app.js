var app = angular.module('HennaByHasna', ['ngRoute','ngMaterial','ngMdIcons','jkAngularCarousel'])

app.config(function($routeProvider) {
    $routeProvider
	 .when("/", {
		controller: "HomeController",
        templateUrl : "home.html"
     })
	 
	 .when("/portfolio", { 
		controller: "PortfolioController",
        templateUrl : "portfolio.html"
     })

	 .when("/service", { 
		controller  : "ServiceController",
        templateUrl : "service.html"
     })
	 
	 .when("/contact", { 
		controller: "ContactController",
        templateUrl : "contact.html"
     });  
});