var app = angular.module('HennaByHasna', ['ngRoute','ngMaterial','ngMdIcons','jkAngularCarousel'])
