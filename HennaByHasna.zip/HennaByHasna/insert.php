<?php
include "connectdb.php";
$data= json_decode(file_get_contents("php://input"));

$controllerFinder  = $data->controllerFinder;
if($controllerFinder == "ContactDetailsReference"){
	$cus_name = $data->cus_name;
	$cus_email = $data->cus_email;
	$cus_phno = $data->cus_phno;
	$add_info = $data->add_info;
	
$query = mysql_query("INSERT into user_data VALUES('".$cus_name."','".$cus_email."',$cus_phno,'".$add_info."')");
}

?>