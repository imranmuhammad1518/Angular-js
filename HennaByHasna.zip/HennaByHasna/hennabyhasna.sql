-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 03, 2018 at 08:31 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hennabyhasna`
--

-- --------------------------------------------------------

--
-- Table structure for table `page_contents`
--

CREATE TABLE IF NOT EXISTS `page_contents` (
  `about_info` varchar(1000) NOT NULL,
  `by_info` varchar(1000) NOT NULL,
  `abt_henna` varchar(5000) NOT NULL,
  `ph_no` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `page_contents`
--

INSERT INTO `page_contents` (`about_info`, `by_info`, `abt_henna`, `ph_no`) VALUES
('Hasna started hennaing at the times back from her childhood for eid and in special occasions to her friends and family. Now her passion took her way to do it professionally. She is a professional henna/mehandi artist, who does alluring mehandi for all special occasions. Adore yourself with this form of body art which enlightens your happiness in your special day. She does henna for bridals, engagement, baby shower, birthday parties, sangeet, house warming parties, Diwali, Eid, Christmas events.', '"As far as I remember I had this unquenchable curiosity and a hunger to do thing that resonates my soul, I wanted to be in a job that makes me successful, evidently happy and creatively fulfilled. I was also passionate about motivational writings, entrepreneurship, Makeup, creativity, individuality, fitness and it keeps on going. After failure at a corporate job and anxiety to choose one thing of my life, I found my unusual creative thoughts and innovations at art is my strength and I thought of giving it a go!! I wanted to share my love for henna with others that''s how ''Henna By Hasna'' begun and its on its path as a happy business satisfying people with their henna needs"', 'Henna is traditionally used for special occasions like holidays, birthdays and weddings in Africa, Pakistan, India, and the Middle East. The most popular of the traditions is the Mehndi (henna) Night where the bride, her family, relatives and friends get together to celebrate the wedding to come. Because of this staining quality, Henna has been used throughout the ages to dye hair and create body art designs. Mehandi originated in the deserts of India when the people living there discovered that covering their hands and feet with colored paste from the Henna plant helped them to feel cooler. Henna works on all skin types and colors.  It looks just as beautiful on dark skin as light skin but because some people skin may take the dye better than others, it can look more prominent on one and not as much on another (even lighter skin).  But nevertheless, henna is a symbol of beauty, art, and happiness and is meant for EVERYONE!', '8344524069');

-- --------------------------------------------------------

--
-- Table structure for table `user_data`
--

CREATE TABLE IF NOT EXISTS `user_data` (
  `user_name` varchar(30) NOT NULL,
  `user_email` varchar(30) NOT NULL,
  `ph_no` varchar(15) NOT NULL,
  `add_info` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `page_contents`
--
ALTER TABLE `page_contents`
 ADD PRIMARY KEY (`ph_no`), ADD FULLTEXT KEY `by_info` (`by_info`), ADD FULLTEXT KEY `ph_no` (`ph_no`);

--
-- Indexes for table `user_data`
--
ALTER TABLE `user_data`
 ADD PRIMARY KEY (`ph_no`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
