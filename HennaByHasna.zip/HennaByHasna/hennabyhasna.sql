-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2017 at 08:29 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hennabyhasna`
--

-- --------------------------------------------------------

--
-- Table structure for table `page_contents`
--

CREATE TABLE IF NOT EXISTS `page_contents` (
  `about_info` varchar(1000) NOT NULL,
  `by_info` varchar(1000) NOT NULL,
  `ph_no` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `page_contents`
--

INSERT INTO `page_contents` (`about_info`, `by_info`, `ph_no`) VALUES
('Hasna started hennaing at the times back from her childhood for eid and in special occasions to her friends and family. Now her passion took her way to do it professionally. She is a professional henna/mehandi artist, who does alluring mehandi for all special occasions. Adore yourself with this form of body art which enlightens your happiness in your special day. She does henna for bridals, engagement, baby shower, birthday parties, sangeet, house warming parties, Diwali, Eid, Christmas events.', '"As far as I remember I had this unquenchable curiosity and a hunger to do thing that resonates my soul, I wanted to be in a job that makes me successful, evidently happy and creatively fulfilled. I was also passionate about motivational writings, entrepreneurship, Makeup, creativity, individuality, fitness and it keeps on going. After failure at a corporate job and anxiety to choose one thing of my life, I found my unusual creative thoughts and innovations at art is my strength and I thought of giving it a go!! I wanted to share my love for henna with others that''s how ''Henna By Hasna'' begun and its on its path as a happy business satisfying people with their henna needs"', '8344524069');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `page_contents`
--
ALTER TABLE `page_contents`
 ADD PRIMARY KEY (`ph_no`), ADD FULLTEXT KEY `by_info` (`by_info`), ADD FULLTEXT KEY `ph_no` (`ph_no`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
