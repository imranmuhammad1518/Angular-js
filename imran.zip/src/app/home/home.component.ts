import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { 
  }

  firstContent: boolean = false;
  showFiller = false;
  minimizeIcon : boolean = false;
  menuIcon : boolean = true;

  openDrawer(){
    this.menuIcon = false;
    this.minimizeIcon = true;
  }

  closeDrawer(){
    this.menuIcon = true;
    this.minimizeIcon = false;
  }

  ngOnInit() {
  }

}
