import {Component, OnInit, Inject} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<SignupComponent>) {
      dialogRef.disableClose = true;
       //to prevent back button in browser
    history.pushState(null, null, '');
    window.addEventListener('popstate', function(event) {
      dialogRef.disableClose = true;
    history.pushState(null, null, '');
    });
    }

    emailFormControl = new FormControl('', [
      Validators.required,
      Validators.email,
    ]);

    closeDialog(){
      this.dialogRef.close();
    }
    
    onNoClick(): void {
      this.dialogRef.close();
    }

    ngOnInit() {
    }

    genderList = [
      'Male',
      'Female'
    ];

}
