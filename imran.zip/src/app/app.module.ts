import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {FormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http'; 
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

//npm install material-design-icons
//git clone http://github.com/google/material-design-icons/

import { MatButtonModule,
  MatDialogModule,
  MatCardModule,
  MatMenuModule, 
  MatInputModule,
  MatFormFieldModule,
  MatTabsModule,
  MatButtonToggleModule,
  MatTableModule,
  MatGridListModule,
  MatSelectModule,
  MatOptionModule,
  MatCheckboxModule,
  MatTooltipModule,
  MatPaginatorModule,
  MatSortModule,
  MatRadioModule,
  MatSidenavModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatIconModule
  } from '@angular/material';

import { FlexLayoutModule } from "@angular/flex-layout";

//router imports
import { routes } from "./app.router";
import { Routes,RouterModule } from "@angular/router";

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { SignupComponent } from './signup/signup.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    SignupComponent
  ],
  entryComponents: [SignupComponent],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    routes,
    MatButtonModule,
    MatDialogModule,
    MatCardModule,
    MatMenuModule,
    MatInputModule,
    MatFormFieldModule,
    MatTabsModule,
    MatButtonToggleModule,
    MatTableModule,
    MatGridListModule,
    MatSelectModule,
    MatOptionModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatPaginatorModule,
    MatSortModule,
    MatRadioModule,
    FlexLayoutModule,
    MatSidenavModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatIconModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
