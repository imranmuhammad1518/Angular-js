<?php
define("HOSTNAME","localhost");
define("USERNAME","root");
define("PASSWORD","");
define("DATABASE","employee");

$con=mysql_connect(HOSTNAME,USERNAME,PASSWORD) OR die(mysql_error());
$connect=mysql_select_db("employee");

?>

