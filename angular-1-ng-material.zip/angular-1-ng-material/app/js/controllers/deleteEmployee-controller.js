app.controller('DeleteEmployee',['$scope','$http','$location',function($scope,$http,$location){

$scope.isDisabled = false;

		$scope.backToEmployee = function() {
			 $location.url('/employee');
			 } ;
	 
		$scope.getDetails = function(){
		$scope.errorMsg="";
		$scope.datas='';
			 
		$scope.employeeDetails = "employeeDetails";
		
			$http.post("select.php",{'controllerFinder':$scope.employeeDetails,'emp_empId':$scope.emp_id})
			.then(function(response){
				$scope.data=response.data;
				
				if($scope.data.emp_id == $scope.emp_id){
					$scope.datas=$scope.data;
					//enabling update button
					$scope.isDisabled = true;
				}
				else {
				$scope.errorMsg="Employee Id Not Registered..";
				$scope.isDisabled = false;
			}
		});
	 }
}]);