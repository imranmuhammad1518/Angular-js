app.controller('EmployeeController',['$scope','$location',function($scope,$location){

		$scope.incoming_msg_value = localStorage.sharing_username

		$scope.addEmployee = function() {
			$location.url('/addEmployee');
			 } ;
			 
	    $scope.editEmployee = function() {
			$location.url('/editEmployee');
			 } ;
			 
		$scope.deleteEmployee = function() {
			$location.url('/deleteEmployee');
			 } ;
			
		$scope.searchEmployee = function() {
			$location.url('/searchEmployee');
			 } ;
		$scope.signOut = function() {
			$location.url('/login');
			 } ;	 
			 
}]);