app.controller('LoginController',['$scope','$http','$location',function($scope,$http,$location){
			
	$scope.getData = function(){
	
    $scope.signUpPage = "userTableReference";	
	
	$http.post("select.php",{'controllerFinder':$scope.signUpPage,'login_emailid':$scope.login_emailid})
		
	.then(function(response){
	 $scope.data=response.data
	 localStorage.sharing_username = $scope.data.username
	
			if($scope.data.email_id == $scope.login_emailid && $scope.data.password == $scope.login_password){
				$location.url('/employee');
			}
			else{
				$scope.errorMsg="INVALID CREDENTIALS";
			}
		
	});
	 }
	 
	 $scope.resetAll = function(){
    $scope.login_emailid = null;
	$scope.login_password = null;
	}

	 $scope.navigateSignup = function(){
	 $location.url('/signUp');
	 } 
	 
}]);