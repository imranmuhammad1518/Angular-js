app.directive("validPassword",[function(){
	
	return {
		
			require : 'ngModel',
			link : function(scope,element,attribute,ctrl){
				ctrl.$parsers.push(function(){
					
					var noMatch = scope.signUp.u_retype_password.$viewValue === scope.signUp.u_password.$viewValue;
					scope.signUp.u_password.$setValidity('noMatch',noMatch);
					scope.signUp.u_retype_password.$setValidity('noMatch',noMatch);
					return noMatch ? noMatch : !noMatch;
				});
				
			}
	};
}]);



	